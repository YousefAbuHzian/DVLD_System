﻿using BussinessLayer;
using FullRealProject.Controls;
using FullRealProject.Global_Classes;
using FullRealProject.International_Licenses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.Driving_License_Forms
{
    public partial class frmRenewLicense : Form
    {
        int _NewLicenseID = -1;
        public frmRenewLicense()
        {
            InitializeComponent();
        }

        private void _Load()
        {
            ctrDriverLicenseInfoWithFilter1.tbLicenseIDFocus();

            lblAppDate.Text = DateTime.Now.ToShortDateString();
            lblIssueDate.Text = lblAppDate.Text;

            lblExpirationDate.Text = "???";
            lblApplicationFees.Text = clsApplicationType.Find((int)clsApplication.enApplicationType.RenewDrivingLicense).ApplicationFees.ToString();
            lblCreatedBy.Text = clsGlobal.CurrentUser.UserName;


            llLicenseInfo.Enabled = false;
            llLicensesHistory.Enabled = false;
            btnIssue.Enabled = false;


        }
        

        private void frmRenewLicense_Load(object sender, EventArgs e)
        {
            _Load();
        }

        private void ctrDriverLicenseInfoWithFilter1_OnLicenseSelected(int obj)
        {
            int SelectedLicenseID = obj;

            lblOldLicenseID.Text = SelectedLicenseID.ToString();


            if (SelectedLicenseID == -1)

            {
                return;
            }

            int DefaultValidityLength = ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.LicenseClassInfo.DefaultValidityLength;
            lblExpirationDate.Text = DateTime.Now.AddYears(DefaultValidityLength).ToShortDateString();
            lblLicenseFees.Text = ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.LicenseClassInfo.ClassFees.ToString();
            lblTotalFees.Text = (Convert.ToDecimal(lblApplicationFees.Text) + Convert.ToDecimal(lblLicenseFees.Text)).ToString();
            tbNotes.Text = ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.Notes;


            //check the license is not Expired.
            if (!ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.IsLicenseExpired())
            {
                MessageBox.Show("Selected License is not yet expiared, it will expire on: " + ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.ExpirationDate.ToShortDateString(), "Not allowed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnIssue.Enabled = false;
                return;
            }

            //check the license is not Active.
            if (!ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.IsActive)
            {
                MessageBox.Show("Selected License is not Not Active, choose an active license."
                    , "Not allowed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnIssue.Enabled = false;
                return;
            }




            llLicensesHistory.Enabled = true;
            btnIssue.Enabled = true;

        }

        
        private void btnIssue_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("Are you sure you want to issue the license?", "Confirm",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                return;
            }
            clsLicense NewLicense =
                ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.RenewLicense(tbNotes.Text.Trim()
                , clsGlobal.CurrentUser.UserID);

 
            if (NewLicense != null)
            {
                _NewLicenseID = NewLicense.LicenseID;
                MessageBox.Show($"License Renewed Successfully With ID = {_NewLicenseID}"
                    , "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                lblRLAppID.Text = NewLicense.ApplicationID.ToString();
                lblRenewedLicenseID.Text = _NewLicenseID.ToString();
                ctrDriverLicenseInfoWithFilter1.EnableFilter = false;
                llLicenseInfo.Enabled = true;
                btnIssue.Enabled = false;
            }
            else
            {
                MessageBox.Show("Faild to Renew the License", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }


        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void llLicenseInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmDriverLicenseInfo frm = new frmDriverLicenseInfo(_NewLicenseID);
            frm.ShowDialog();
        }

        private void llLicensesHistory_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmShowPersonLicenseHistory frm =
                new frmShowPersonLicenseHistory(ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.DriverInfo.PersonInfo.NationalNo);
            frm.ShowDialog();
        }
    }
}
