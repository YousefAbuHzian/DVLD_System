﻿using BussinessLayer;
using System;
using FullRealProject.Global_Classes;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.Driving_License_Forms
{
    public partial class frmIssueDrivingLicnese : Form
    {
        int _LDLAppID;
        clsLocalDrivingLicenseApplication _LDLApp;
        public frmIssueDrivingLicnese(int LDLAppID)
        {
            InitializeComponent();
            _LDLAppID = LDLAppID;
        }

        private void _Load()
        {
             _LDLApp = clsLocalDrivingLicenseApplication.Find(_LDLAppID);
            if (_LDLApp == null)
            {

                MessageBox.Show("No Applicaiton with ID=" + _LDLAppID.ToString(), "Not Allowed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }
            if (!_LDLApp.PassedAllTests())
            {

                MessageBox.Show("Person Should Pass All Tests First.", "Not Allowed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }
            int LicenseID = _LDLApp.GetActiveLicenseID();
            if (LicenseID != -1)
            {

                MessageBox.Show("Person already has License before with License ID=" + LicenseID.ToString(), "Not Allowed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;

            }
            ctrLocalDrivingLicenseAppDetails1.LoadLDLAppInfo(_LDLAppID);

            //lblFees.Text = clsLicenseClass.Find(_LDLApp.LicenseClassID).ClassFees.ToString();
            lblFees.Text = _LDLApp.LicenseClassInfo.ClassFees.ToString();
        }
      
        private void frmIssueDrivingLicnese_Load(object sender, EventArgs e)
        {
            _Load();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnIssue_Click(object sender, EventArgs e)
        {

            int LicenseID =
                _LDLApp.IssueLicenseForTheFirtTime(tbNotes.Text.Trim(), clsGlobal.CurrentUser.UserID);


            if (LicenseID != -1)
            {
                MessageBox.Show("License Issued Successfully with License ID = " + LicenseID.ToString(),
                    "Succeeded", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Close();
            }
            else
            {
                MessageBox.Show("License Was not Issued ! ",
                 "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}
