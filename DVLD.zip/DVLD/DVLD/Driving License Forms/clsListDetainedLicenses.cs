﻿using BussinessLayer;
using FullRealProject.PeopleForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.Driving_License_Forms
{
    public partial class clsListDetainedLicenses : Form
    {
        private DataTable _dtDetainedLicenses;
        public clsListDetainedLicenses()
        {
            InitializeComponent();
        }

        private void _Refresh()
        {
            
            _dtDetainedLicenses = clsDetainLicense.GetAllDetainedLicenses();
           
            
            dgvAllDetainedLicenses.DataSource = _dtDetainedLicenses;
            lblRecordsCount.Text = (dgvAllDetainedLicenses.RowCount).ToString();

            releaseDetainedLicenseToolStripMenuItem.Enabled = false;
        }
        private void clsListDetainedLicenses_Load(object sender, EventArgs e)
        {
            _Refresh();
            cbFilter.SelectedIndex = 0;
            tbFilter.Visible = false;
            if (dgvAllDetainedLicenses.Rows.Count > 0)
            {
                dgvAllDetainedLicenses.Columns[0].HeaderText = "D.ID";

                dgvAllDetainedLicenses.Columns[1].HeaderText = "L.ID";

                dgvAllDetainedLicenses.Columns[2].HeaderText = "D.Date";

                dgvAllDetainedLicenses.Columns[3].HeaderText = "Is Released";

                dgvAllDetainedLicenses.Columns[4].HeaderText = "Fine Fees";

                dgvAllDetainedLicenses.Columns[5].HeaderText = "Release Date";

                dgvAllDetainedLicenses.Columns[6].HeaderText = "N.No.";

                dgvAllDetainedLicenses.Columns[7].HeaderText = "Full Name";

                dgvAllDetainedLicenses.Columns[8].HeaderText = "Rlease App.ID";

            }
        }

        private void btnDetainLicense_Click(object sender, EventArgs e)
        {
            frmDetainLicense frm = new frmDetainLicense();
            frm.ShowDialog();
            _Refresh();
        }

        private void btnReleaseLicense_Click(object sender, EventArgs e)
        {
            frmReleaseDetainedLicense frm = new frmReleaseDetainedLicense();
            frm.ShowDialog();
            _Refresh();
        }

        private void cbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbFilter.SelectedIndex == 0)
            {
                tbFilter.Visible = false;
                cbIsActive.Visible = false;
                
            }
            else if (cbFilter.SelectedIndex == 2)
            {
                tbFilter.Visible = false;
                cbIsActive.Visible = true;
                cbIsActive.SelectedIndex = 0;
            }
            else
            {
                tbFilter.Visible = true;
                cbIsActive.Visible = false;
            }
            tbFilter.Text = "";
            tbFilter.Focus();
            //_dtDetainedLicenses.DefaultView.RowFilter = "";
        }
        private void cbIsActive_SelectedIndexChanged(object sender, EventArgs e)
        {
            string FilterColumn = "IsReleased";
            string FilterValue = cbIsActive.Text;

            switch (FilterValue)
            {
                case "All":
                    break;
                case "Yes":
                    FilterValue = "1";
                    break;
                case "No":
                    FilterValue = "0";
                    break;
            }


            if (FilterValue == "All")
                _dtDetainedLicenses.DefaultView.RowFilter = "";
            else
                //in this case we deal with numbers not string.
                _dtDetainedLicenses.DefaultView.RowFilter = string.Format("[{0}] = {1}", FilterColumn, FilterValue);

            lblRecordsCount.Text = _dtDetainedLicenses.Rows.Count.ToString();


        }

        

        private void tbFilter_TextChanged(object sender, EventArgs e)
        {
            string FilterColumn = "";
            //Map Selected Filter to real Column name 
            switch (cbFilter.Text)
            {
                case "Detain ID":
                    FilterColumn = "DetainID";
                    break;
                case "Is Released":
                    {
                        FilterColumn = "IsReleased";
                        break;
                    }
                    ;

                case "National No.":
                    FilterColumn = "NationalNo";
                    break;


                case "Full Name":
                    FilterColumn = "FullName";
                    break;

                case "Release Application ID":
                    FilterColumn = "ReleaseApplicationID";
                    break;

                default:
                    FilterColumn = "None";
                    break;
            }


            //Reset the filters in case nothing selected or filter value conains nothing.
            if (tbFilter.Text.Trim() == "" || FilterColumn == "None")
            {
                _dtDetainedLicenses.DefaultView.RowFilter = "";
                lblRecordsCount.Text = dgvAllDetainedLicenses.Rows.Count.ToString();
                return;
            }


            if (FilterColumn == "DetainID" || FilterColumn == "ReleaseApplicationID")
                //in this case we deal with numbers not string.
                _dtDetainedLicenses.DefaultView.RowFilter = string.Format("[{0}] = {1}", FilterColumn, tbFilter.Text.Trim());
            else
                _dtDetainedLicenses.DefaultView.RowFilter = string.Format("[{0}] LIKE '{1}%'", FilterColumn, tbFilter.Text.Trim());

            lblRecordsCount.Text = dgvAllDetainedLicenses.Rows.Count.ToString();
        }

        private void tbFilter_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (cbFilter.Text == "Detain ID" || cbFilter.Text == "Release Application ID")
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                {
                    e.Handled = true; // block the input
                }
            }
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            var row = dgvAllDetainedLicenses.SelectedRows[0];
            bool IsReleased = Convert.ToBoolean(row.Cells[3].Value);

            releaseDetainedLicenseToolStripMenuItem.Enabled = !IsReleased;
       


        }

        private void showPersonDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clsPeople person = clsPeople.Find(dgvAllDetainedLicenses.CurrentRow.Cells[6].Value.ToString());
            frmShowDetails frm = new frmShowDetails(person.PersonID);
            frm.ShowDialog();
           
        }

        private void showLicenseDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDriverLicenseInfo frm = new frmDriverLicenseInfo(Convert.ToInt32(dgvAllDetainedLicenses.CurrentRow.Cells[1].Value));
            frm.ShowDialog();
        }

        private void showPersonLicenseHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmShowPersonLicenseHistory frm = new frmShowPersonLicenseHistory(dgvAllDetainedLicenses.CurrentRow.Cells[6].Value.ToString());
            frm.ShowDialog();
        }

        private void releaseDetainedLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReleaseDetainedLicense frm = new frmReleaseDetainedLicense(Convert.ToInt32(dgvAllDetainedLicenses.CurrentRow.Cells[1].Value));
            frm.ShowDialog();
            _Refresh();
        }
    }
}
