﻿using BussinessLayer;
using FullRealProject.Controls;
using FullRealProject.Global_Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static BussinessLayer.clsLicense;

namespace FullRealProject.Driving_License_Forms
{
    public partial class frmReplacmentDrivingLicense : Form
    {
        private int _NewLicenseID = -1;
        public frmReplacmentDrivingLicense()
        {
            InitializeComponent();
        }

        //private int _GetApplicationTypeID()
        //{
        //    //this will decide which application type to use accirding 
        //    // to user selection.

        //    if (rbDamagedLicense.Checked)

        //        return (int)clsApplication.enApplicationType.ReplaceDamagedDrivingLicense;
        //    else
        //        return (int)clsApplication.enApplicationType.ReplaceLostDrivingLicense;
        //}
        private enIssueReason _GetIssueReason()
        {
            //this will decide which reason to issue a replacement for

            if (rbDamagedLicense.Checked)

                return enIssueReason.DamagedReplacement;
            else
                return enIssueReason.LostReplacement;
        }


        private void _Load()
        {
            lblApplicationFees.Text = clsApplicationType.Find((int)clsApplication.enApplicationType.ReplaceDamagedDrivingLicense).ApplicationFees.ToString();
            lblCreatedby.Text = clsGlobal.CurrentUser.UserName;
            lblAppDate.Text = DateTime.Now.ToShortDateString();
            ctrDriverLicenseInfoWithFilter1.tbLicenseIDFocus();

            btnIssue.Enabled = false;
            llLicenseInfo.Enabled = false;
            llLicensesHistory.Enabled = false;
            
        }
        private void rbDamagedLicense_CheckedChanged(object sender, EventArgs e)
        {
            if (rbDamagedLicense.Checked)
            {
                lblTitle.Text = "Replacement for Damaged License";
                lblApplicationFees.Text = clsApplicationType.Find((int)clsApplication.enApplicationType.ReplaceDamagedDrivingLicense).ApplicationFees.ToString();
            }
            else
            {
                lblTitle.Text = "Replacement for Lost License";
                lblApplicationFees.Text = clsApplicationType.Find((int)clsApplication.enApplicationType.ReplaceLostDrivingLicense).ApplicationFees.ToString();
            }
            this.Text = lblTitle.Text;
        }

        private void frmReplacmentDrivingLicense_Load(object sender, EventArgs e)
        {
            _Load();
        }

        

        private void ctrDriverLicenseInfoWithFilter1_OnLicenseSelected(int obj)
        {
            int SelectedLicenseID = (int)obj;
            lblOldLicenseID.Text = SelectedLicenseID.ToString();
            if (SelectedLicenseID == -1)
            {
                return;
            }

            llLicensesHistory.Enabled = true;
            //dont allow a replacement if Not Active .

            if (!ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.IsActive)
            {
                MessageBox.Show("Selected License is  Not Active, choose an active license."
                    , "Not allowed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnIssue.Enabled = false;
                return;
            }


            
            btnIssue.Enabled = true;
        }


        private void btnIssue_Click(object sender, EventArgs e)
        {



            if (MessageBox.Show("Are you sure you want to Issue a Replacement for the license?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                return;
            }

            clsLicense NewLicense =
               ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.Replace(_GetIssueReason(),
               clsGlobal.CurrentUser.UserID);



            if (NewLicense != null)
            {
                _NewLicenseID = NewLicense.LicenseID;
                MessageBox.Show($"License Replaced Successfully With ID = {_NewLicenseID}"
                    , "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                lblLRAppID.Text = NewLicense.ApplicationID.ToString();
                lblRepalcedLicenseID.Text = _NewLicenseID.ToString();

                groupBox2.Enabled = false;
                ctrDriverLicenseInfoWithFilter1.EnableFilter = false;
                llLicenseInfo.Enabled = true;
                btnIssue.Enabled = false;
            }
            else
            {
                MessageBox.Show($"License Was Not Replaced"
                    , "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void llLicenseInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmDriverLicenseInfo frm = new frmDriverLicenseInfo(_NewLicenseID);
            frm.ShowDialog();
        }

        private void llLicensesHistory_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmShowPersonLicenseHistory frm =
                new frmShowPersonLicenseHistory(ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.DriverInfo.PersonInfo.NationalNo);
            frm.ShowDialog();
        }
    }
}
