﻿using BussinessLayer;
using FullRealProject.Controls;
using FullRealProject.Global_Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.Driving_License_Forms
{
    public partial class frmDetainLicense : Form
    {
        private int _DetainID = -1;
        private int _SelectedLicenseID = -1;
        public frmDetainLicense()
        {
            InitializeComponent();
        }

        private void _Load()
        {

            lblDetainDate.Text = DateTime.Now.ToShortDateString();
            lblCreatedby.Text = clsGlobal.CurrentUser.UserName;

            btnDetain.Enabled = false;
            llLicenseInfo.Enabled = false;
            llLicensesHistory.Enabled = false;
        }

        private void frmDetainLicense_Load(object sender, EventArgs e)
        {
            _Load();
            ctrDriverLicenseInfoWithFilter1.tbLicenseIDFocus();
        }

       
        private void ctrDriverLicenseInfoWithFilter1_OnLicenseSelected(int obj)
        {
            _SelectedLicenseID = obj;
           


            lblLicenseID.Text = _SelectedLicenseID.ToString();

            if (_SelectedLicenseID == -1)
            {
                return;
            }

            llLicensesHistory.Enabled = true;

            if (ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.IsDetained)
            {
                MessageBox.Show("This License is Already Detained!", "Not Allowed", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            
            tbFineFees.Focus();

            btnDetain.Enabled = true;
        }

        private void btnDetain_Click(object sender, EventArgs e)
        {
            if (!this.ValidateChildren())
            {
                MessageBox.Show("Some Feilds Are Empty!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (MessageBox.Show("Are you sure you want to Detain the license?", "Confirm",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                return;
            }

            _DetainID = ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.Detain(Convert.ToDecimal(tbFineFees.Text.Trim()),
                clsGlobal.CurrentUser.UserID);

            if (_DetainID != -1)
            {
                MessageBox.Show($"License Detained Successfully With Detain ID = {_DetainID}"
                    , "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                lblDetainID.Text = _DetainID.ToString();
                ctrDriverLicenseInfoWithFilter1.EnableFilter = false;
                llLicenseInfo.Enabled = true;
                btnDetain.Enabled = false;
                tbFineFees.Enabled = false;
            }
            else
            {
                MessageBox.Show($"License Was Not Detained"
                    , "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void llLicensesHistory_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmShowPersonLicenseHistory frm = 
                new frmShowPersonLicenseHistory(ctrDriverLicenseInfoWithFilter1
                .SelectedLicenseInfo.DriverInfo.PersonInfo.PersonID);
            frm.ShowDialog();
        }

        private void llLicenseInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmDriverLicenseInfo frm = new frmDriverLicenseInfo(_SelectedLicenseID);
            frm.ShowDialog();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }    

        private void tbFineFees_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '.' && tbFineFees.Text.Contains('.'))
            {
                e.Handled = true;
            }
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true; // block the input
            }
        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void ctrDriverLicenseInfoWithFilter1_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void tbFineFees_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(tbFineFees.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(tbFineFees, "Fees cannot be empty!");
                return;
            }
            else
            {
                errorProvider1.SetError(tbFineFees, null);

            }


            if (!clsValidation.IsNumber(tbFineFees.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(tbFineFees, "Invalid Number.");
            }
            else
            {
                errorProvider1.SetError(tbFineFees, null);
            }
            
        }
    }
}
