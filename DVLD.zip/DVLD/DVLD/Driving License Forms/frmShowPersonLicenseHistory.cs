﻿using BussinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.Driving_License_Forms
{
    public partial class frmShowPersonLicenseHistory : Form
    {
        string _NationalNo;
        int _PersonID = -1;
        public frmShowPersonLicenseHistory(string NationalNo)
        {
            InitializeComponent();
            _NationalNo = NationalNo;
        }
        public frmShowPersonLicenseHistory(int PersonID)
        {
            InitializeComponent();
            _PersonID = PersonID;
        }

        private void _Load()
        {
            clsPeople person;
            if (_PersonID != -1)
            {
                person = clsPeople.Find(_PersonID);
            }
            else
            {
                person = clsPeople.Find(_NationalNo);
            }
            if (person == null)
            {
                MessageBox.Show("This Person Does not Exist", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }
                
            ctrPersonDetails1.LoadPersonInfo(person.NationalNo);
            ctrDriverLicenses1.LoadControl(person.PersonID);
        }


        private void frmShowPersonLicenseHistory_Load(object sender, EventArgs e)
        {
            _Load();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
