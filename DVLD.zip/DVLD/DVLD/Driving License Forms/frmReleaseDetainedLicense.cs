﻿using BussinessLayer;
using FullRealProject.Controls;
using FullRealProject.Global_Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.Driving_License_Forms
{
    public partial class frmReleaseDetainedLicense : Form
    {
        private int _SelectedLicenseID = -1;

        public frmReleaseDetainedLicense()
        {
            InitializeComponent();    
            
        }
        public frmReleaseDetainedLicense(int LicenseID)
        {
            InitializeComponent();
            _SelectedLicenseID = LicenseID;

            ctrDriverLicenseInfoWithFilter1.LoadLicenseInfo(_SelectedLicenseID);
            ctrDriverLicenseInfoWithFilter1.EnableFilter = false;

        }

  

        private void frmReleaseDetainedLicense_Load(object sender, EventArgs e)
        {
            ctrDriverLicenseInfoWithFilter1.tbLicenseIDFocus();
        }

        private void ctrDriverLicenseInfoWithFilter1_OnLicenseSelected(int obj)
        {
            _SelectedLicenseID = obj;

            lblLicenseID.Text = _SelectedLicenseID.ToString();

            if (_SelectedLicenseID == -1)

            {
                return;
            }

            llLicensesHistory.Enabled = true;
            //ToDo: make sure the license is not detained already.
            if (!ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.IsDetained)
            {
                MessageBox.Show("Selected License is Not Detained!, choose another one.", "Not allowed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (!ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.IsActive)
            {
                MessageBox.Show("This License is not Active!", "Not Allowed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            lblApplicationFees.Text = clsApplicationType.Find((int)clsApplication.enApplicationType.ReleaseDetainedDrivingLicsense).ApplicationFees.ToString();

            lblDetainID.Text = ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.DetainedInfo.DetainID.ToString();
            lblLicenseID.Text = ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.LicenseID.ToString();

            lblCreatedby.Text = ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.DetainedInfo.CreatedByUserInfo.UserName;
            lblDetainDate.Text = ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.DetainedInfo.DetainDate.ToShortDateString();
            lblFineFees.Text = ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.DetainedInfo.FineFees.ToString();
            lblTotalFees.Text = (Convert.ToSingle(lblApplicationFees.Text) + Convert.ToSingle(lblFineFees.Text)).ToString();

            btnRelease.Enabled = true;

        }

        private void btnRelease_Click(object sender, EventArgs e)
        {
                  

            if (MessageBox.Show("Are you sure you want to Release the license?", "Confirm",
               MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                return;
            }

            int ApplicationID = -1;

            bool IsReleased = ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.ReleaseDetainedLicense(clsGlobal.CurrentUser.UserID, ref ApplicationID); ;

            lblRApplicationID.Text = ApplicationID.ToString();

            

            if (IsReleased)
            {
                MessageBox.Show($"License Has been Released Successfully!"
                    , "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ctrDriverLicenseInfoWithFilter1.EnableFilter = false;
                llLicenseInfo.Enabled = true;
                btnRelease.Enabled = false;
            }
            else
            {
                MessageBox.Show($"License Was Not Detained"
                    , "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void llLicensesHistory_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmShowPersonLicenseHistory frm =
             new frmShowPersonLicenseHistory(ctrDriverLicenseInfoWithFilter1.
             SelectedLicenseInfo.DriverInfo.PersonID);
            frm.ShowDialog();
            
        }

        private void llLicenseInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            frmDriverLicenseInfo frm = new frmDriverLicenseInfo(_SelectedLicenseID);
            frm.ShowDialog();
        }
    }
}
