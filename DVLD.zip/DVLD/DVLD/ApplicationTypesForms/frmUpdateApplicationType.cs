﻿using BussinessLayer;
using FullRealProject.Global_Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.ApplicationTypesForms
{
    public partial class frmUpdateApplicationType : Form
    {
        int _ApplicationTypeID;

        clsApplicationType _ApplicationType;
        public frmUpdateApplicationType(int ApplicationTypeID)
        {
            InitializeComponent();
            _ApplicationTypeID = ApplicationTypeID;
        }

       
        private void _LoadUI()
        {
            _ApplicationType = clsApplicationType.Find(_ApplicationTypeID);
            if (_ApplicationType == null)
            {
                MessageBox.Show("ApplicationType was not found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }
            lblAppID.Text = _ApplicationTypeID.ToString();
            tbTitle.Text = _ApplicationType.ApplicationTypeTitle.ToString();
            tbFees.Text = _ApplicationType.ApplicationFees.ToString();
        }

       
        private void frmUpdateApplicationType_Load(object sender, EventArgs e)
        {
            _LoadUI();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!this.ValidateChildren())
            {
                MessageBox.Show("Some fileds are not valide!, put the mouse over the red icon(s) to see the erro", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            _ApplicationType.ApplicationTypeTitle = tbTitle.Text.Trim();
            _ApplicationType.ApplicationFees = Convert.ToDecimal(tbFees.Text);


            if (_ApplicationType.UpdateApplicationType())
            {
                MessageBox.Show("Application Type Updated Successfully:)", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Application Type was NOT Updated", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void tbFees_KeyPress(object sender, KeyPressEventArgs e)
        {
            //bool DotInsertedBefore = tbFees.Text.Contains('.'); #if true this means (.) Inserted Before
            if (e.KeyChar == '.' && tbFees.Text.Contains('.'))
            {
                e.Handled = true;
            }
            else
                e.Handled = !char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.';

        }

       
        private void tbTitle_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(tbTitle.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(tbTitle, "Title cannot be empty!");
            }
            else
            {
                errorProvider1.SetError(tbTitle, null);
            }
            
        }

        private void tbFees_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(tbFees.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(tbFees, "Fees cannot be empty!");
            }
            else
            {
                errorProvider1.SetError(tbFees, null);
            }
            if (!clsValidation.IsNumber(tbFees.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(tbFees, "Invalid Number.");
            }
            else
            {
                errorProvider1.SetError(tbFees, null);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
