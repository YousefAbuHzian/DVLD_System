﻿using BussinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.ApplicationTypesForms
{
    public partial class frmManageApplicationTypes : Form
    {
        private DataTable _dtAllApplicationTypes;
        public frmManageApplicationTypes()
        {
            InitializeComponent();
        }

       

        private void _Refresh()
        {
           _dtAllApplicationTypes = clsApplicationType.GetAllApplicationTypes();


            dgvAllApplicationTypes.DataSource = _dtAllApplicationTypes;
            lblRecordsCount.Text = dgvAllApplicationTypes.Rows.Count.ToString();

        }
        private void frmManageApplicationTypes_Load(object sender, EventArgs e)
        {
            _Refresh();
            if (dgvAllApplicationTypes.Rows.Count == 0)           
                return;
            
            dgvAllApplicationTypes.Columns[0].HeaderText = "ID";
            dgvAllApplicationTypes.Columns[0].Width = 60;

            dgvAllApplicationTypes.Columns[1].HeaderText = "Title";
            dgvAllApplicationTypes.Columns[1].Width = 280;

            dgvAllApplicationTypes.Columns[2].HeaderText = "Fees";
            dgvAllApplicationTypes.Columns[2].Width = 100;
        }

        private void editApplicationTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUpdateApplicationType frm = new frmUpdateApplicationType(Convert.ToInt32(dgvAllApplicationTypes.CurrentRow.Cells[0].Value));
            frm.ShowDialog();
            _Refresh();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
