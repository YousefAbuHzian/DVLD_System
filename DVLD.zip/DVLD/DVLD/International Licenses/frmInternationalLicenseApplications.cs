﻿using BussinessLayer;
using FullRealProject.Driving_License_Forms;
using FullRealProject.PeopleForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.International_Licenses
{
    public partial class frmInternationalLicenseApplications : Form
    {
        private DataTable _dtInternationalLicenseApplications;
        public frmInternationalLicenseApplications()
        {
            InitializeComponent();
        }

        private void _Refresh()
        {

            _dtInternationalLicenseApplications = clsInternationalLicense.GetManageInternationalLicenseApplication();
            
             dgvAllILApplications.DataSource = _dtInternationalLicenseApplications;
             lblRecordsCount.Text = (dgvAllILApplications.RowCount).ToString();

            
            
        }
        private void frmInternationalLicenseApplications_Load(object sender, EventArgs e)
        {
            _Refresh();
            cbFilter.SelectedIndex = 0;
            tbFilter.Visible = false;
            if (dgvAllILApplications.Rows.Count > 0)
            {
                dgvAllILApplications.Columns[0].HeaderText = "Int.License ID";

                dgvAllILApplications.Columns[1].HeaderText = "Application ID";

                dgvAllILApplications.Columns[2].HeaderText = "Driver ID";

                dgvAllILApplications.Columns[3].HeaderText = "L.License ID";

                dgvAllILApplications.Columns[4].HeaderText = "Issue Date";

                dgvAllILApplications.Columns[5].HeaderText = "Expiration Date";

                dgvAllILApplications.Columns[6].HeaderText = "Is Active";

            }
        }


        private void cbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cbFilter.Text == "Is Active")
            {
                tbFilter.Visible = false;
                cbIsReleased.Visible = true;
                cbIsReleased.Focus();
                cbIsReleased.SelectedIndex = 0;
            }

            else

            {

                tbFilter.Visible = (cbFilter.Text != "None");
                cbIsReleased.Visible = false;

                if (cbFilter.Text == "None")
                {
                    tbFilter.Enabled = false;
                    //_dtDetainedLicenses.DefaultView.RowFilter = "";
                    //lblTotalRecords.Text = dgvDetainedLicenses.Rows.Count.ToString();

                }
                else
                    tbFilter.Enabled = true;

                tbFilter.Text = "";
                tbFilter.Focus();
            }
        }

       

        private void tbFilter_TextChanged(object sender, EventArgs e)
        {
            string FilterColumn = "";
            //Map Selected Filter to real Column name 
            switch (cbFilter.Text)
            {
                case "International License ID":
                    FilterColumn = "InternationalLicenseID";
                    break;
                case "Application ID":
                    {
                        FilterColumn = "ApplicationID";
                        break;
                    }
                    ;

                case "Driver ID":
                    FilterColumn = "DriverID";
                    break;

                case "Local License ID":
                    FilterColumn = "IssuedUsingLocalLicenseID";
                    break;

                case "Is Active":
                    FilterColumn = "IsActive";
                    break;


                default:
                    FilterColumn = "None";
                    break;
            }


            //Reset the filters in case nothing selected or filter value conains nothing.
            if (tbFilter.Text.Trim() == "" || FilterColumn == "None")
            {
                _dtInternationalLicenseApplications.DefaultView.RowFilter = "";
                lblRecordsCount.Text = dgvAllILApplications.Rows.Count.ToString();
                return;
            }



            _dtInternationalLicenseApplications.DefaultView.RowFilter = string.Format("[{0}] = {1}", FilterColumn, tbFilter.Text.Trim());

            lblRecordsCount.Text = _dtInternationalLicenseApplications.Rows.Count.ToString();

        }

        private void tbFilter_KeyPress(object sender, KeyPressEventArgs e)
        {
            
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                {
                    e.Handled = true; // block the input
                }
            
        }

        private void btnAddILApp_Click(object sender, EventArgs e)
        {
            frmInternationalLicenseApplication frm = new frmInternationalLicenseApplication();
            frm.ShowDialog();
            _Refresh();
        }

        private void showPerosnDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int driverID = Convert.ToInt32(dgvAllILApplications.CurrentRow.Cells[2].Value);
            int PersonID = clsDriver.Find(driverID).PersonID;
            frmShowDetails frm = new frmShowDetails(PersonID);
            frm.ShowDialog();
            _Refresh();
        }

        private void showLicenseDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int internationalLicenseID = Convert.ToInt32(dgvAllILApplications.CurrentRow.Cells[0].Value);
            frmDriverInternationalLicenseInfo frm = new frmDriverInternationalLicenseInfo(internationalLicenseID);
            frm.ShowDialog();
            _Refresh();
        }

        private void showPersonLicenseHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int driverID = Convert.ToInt32(dgvAllILApplications.CurrentRow.Cells[2].Value);
            int PersonID = clsDriver.Find(driverID).PersonID;
            frmShowPersonLicenseHistory frm = new frmShowPersonLicenseHistory(PersonID);
            frm.ShowDialog();
            _Refresh();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cbIsReleased_SelectedIndexChanged(object sender, EventArgs e)
        {
            string FilterColumn = "IsActive";
            string FilterValue = cbIsReleased.Text;

            switch (FilterValue)
            {
                case "All":
                    break;
                case "Yes":
                    FilterValue = "1";
                    break;
                case "No":
                    FilterValue = "0";
                    break;
            }


            if (FilterValue == "All")
                _dtInternationalLicenseApplications.DefaultView.RowFilter = "";
            else
                //in this case we deal with numbers not string.
                _dtInternationalLicenseApplications.DefaultView.RowFilter = string.Format("[{0}] = {1}", FilterColumn, FilterValue);

            lblRecordsCount.Text = _dtInternationalLicenseApplications.Rows.Count.ToString();
        }
    }
}
