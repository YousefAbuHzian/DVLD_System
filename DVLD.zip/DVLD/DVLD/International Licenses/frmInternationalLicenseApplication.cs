﻿using BussinessLayer;
using FullRealProject.Controls;
using FullRealProject.Driving_License_Forms;
using FullRealProject.Global_Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.International_Licenses
{
    public partial class frmInternationalLicenseApplication : Form
    {
        private int _InternationalLicenseID = -1;

        public frmInternationalLicenseApplication()
        {
            InitializeComponent();
        }

        private void _Load()
        {
            lblApplicationDate.Text = DateTime.Now.ToShortDateString();
            lblIssueDate.Text = lblApplicationDate.Text;
            lblExpirationDate.Text = DateTime.Now.AddYears(1).ToShortDateString();//add one year.
            lblFees.Text = clsApplicationType.Find((int)clsApplication.enApplicationType.NewInternationalLicense).ApplicationFees.ToString();
            lblCreatedBy.Text = clsGlobal.CurrentUser.UserName;



            llLicenseInfo.Enabled = false;
            llLicensesHistory.Enabled = false;
            btnIssue.Enabled = false;
        }
        private void frmInternationalLicenseApplication_Load(object sender, EventArgs e)
        {
            _Load();
            ctrDriverLicenseInfoWithFilter1.tbLicenseIDFocus();
        }

        private void ctrDriverLicenseInfoWithFilter1_OnLicenseSelected(int obj)
        {
            int SelectedLicenseID = obj;

            lblLocalLicenseID.Text = SelectedLicenseID.ToString();


            if (SelectedLicenseID == -1)

            {
                return;
            }
            llLicensesHistory.Enabled = true;

            //check the license class, person could not issue international license without having
            //normal license of class 3.

            if (ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.LicenseClass != 3)
            {
                MessageBox.Show("Selected License should be Class 3, select another one.", "Not allowed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            //check if person already have an active international license
            int ActiveInternaionalLicenseID = clsInternationalLicense.GetActiveInternationalLicenseIDByDriverID(ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.DriverID);

            if (ActiveInternaionalLicenseID != -1)
            {
                MessageBox.Show("Person already have an active international license with ID = " + ActiveInternaionalLicenseID.ToString(), "Not allowed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                llLicenseInfo.Enabled = true;
                _InternationalLicenseID = ActiveInternaionalLicenseID;
                btnIssue.Enabled = false;
                return;
            }

            btnIssue.Enabled = true;

        }

        private void llLicensesHistory_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
             
            frmShowPersonLicenseHistory frm =
                new frmShowPersonLicenseHistory(ctrDriverLicenseInfoWithFilter1.
                SelectedLicenseInfo.DriverInfo.PersonID);
            frm.ShowDialog();
        }
        

        private void btnIssue_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to issue the license?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                return;
            }


            clsInternationalLicense InternationalLicense = new clsInternationalLicense();
            //those are the information for the base application, because it inhirts from application, they are part of the sub class.

            InternationalLicense.ApplicantPersonID = ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.DriverInfo.PersonID;
            InternationalLicense.ApplicationDate = DateTime.Now;
            InternationalLicense.Status = clsApplication.enStatus.Completed;
            InternationalLicense.LastStatusDate = DateTime.Now;
            InternationalLicense.PaidFees = clsApplicationType.Find((int)clsApplication.enApplicationType.NewInternationalLicense).ApplicationFees;
            InternationalLicense.CreatedByUserID = clsGlobal.CurrentUser.UserID;


            InternationalLicense.DriverID = ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.DriverID;
            InternationalLicense.IssuedUsingLocalLicenseID = ctrDriverLicenseInfoWithFilter1.SelectedLicenseInfo.LicenseID;
            InternationalLicense.IssueDate = DateTime.Now;
            InternationalLicense.ExpirationDate = DateTime.Now.AddYears(1);

            InternationalLicense.CreatedByUserID = clsGlobal.CurrentUser.UserID;





            if (InternationalLicense.Save())
            {
                MessageBox.Show($"International License Issued Successfully With ID = {InternationalLicense.InternationalLicenseID}"
                    , "License Issued", MessageBoxButtons.OK, MessageBoxIcon.Information);
                lblILApplicationID.Text = InternationalLicense.ApplicationID.ToString();
                lblILicenseID.Text = InternationalLicense.InternationalLicenseID.ToString();
                _InternationalLicenseID = InternationalLicense.InternationalLicenseID;
                ctrDriverLicenseInfoWithFilter1.EnableFilter = false;
                llLicenseInfo.Enabled = true;
                btnIssue.Enabled = false;
            }
            else
            {
                MessageBox.Show($"International License Was Not Issued"
                    , "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void llLicenseInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmDriverInternationalLicenseInfo frm =
                new frmDriverInternationalLicenseInfo(_InternationalLicenseID);
            frm.ShowDialog();
        }

        private void ctrDriverLicenseInfoWithFilter1_Load(object sender, EventArgs e)
        {

        }
    }
}
