﻿using BussinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.Controls
{
    public partial class ctrDriverInternationalLicenseInfo : UserControl
    {
        public ctrDriverInternationalLicenseInfo()
        {
            InitializeComponent();
        }


       


        public void LoadControl(int InternationalLicenseID)
        {
            clsInternationalLicense internationalLicense = clsInternationalLicense.Find(InternationalLicenseID);
            if (internationalLicense == null)
            {
                MessageBox.Show("This International License Does Not Exist!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            lblName.Text = internationalLicense.DriverInfo.PersonInfo.FullName;
            lblIntLicenseID.Text = InternationalLicenseID.ToString();
            lblLicenseID.Text = internationalLicense.IssuedUsingLocalLicenseID.ToString();
            lblNationalNo.Text = internationalLicense.DriverInfo.PersonInfo.NationalNo.ToString();
            lblGender.Text = internationalLicense.DriverInfo.PersonInfo.Gender == 0 ? "Male" : "Female";
            lblIssueDate.Text = internationalLicense.IssueDate.ToShortDateString();
            lblApplicationID.Text = internationalLicense.ApplicationID.ToString();
            lblIsActive.Text = internationalLicense.IsActive ? "Yes" : "No";
            lblDateOfBirth.Text = internationalLicense.DriverInfo.PersonInfo.DateOfBirth.ToShortDateString();
            lblDriverID.Text = internationalLicense.DriverID.ToString();
            lblExpirationDate.Text = internationalLicense.ExpirationDate.ToShortDateString();

            string ImagePath = internationalLicense.DriverInfo.PersonInfo.ImagePath.ToString();

            if (ImagePath != null && ImagePath != "")
            {
                if (File.Exists(ImagePath))
                    pictureBox1.ImageLocation = ImagePath;
                else
                {
                    MessageBox.Show("Image Does Not Exists", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }                      
            else
            {
                if (internationalLicense.DriverInfo.PersonInfo.Gender == 0)
                    pictureBox1.Image = Properties.Resources.anonymous;
                else
                    pictureBox1.Image = Properties.Resources.anonymous_woman;
            }

        }
        private void ctrDriverInternationalLicenseInfo_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
