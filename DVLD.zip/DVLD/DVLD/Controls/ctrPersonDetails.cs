﻿using BussinessLayer;
using FullRealProject.PeopleForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.UserControls
{
    public partial class ctrPersonDetails : UserControl
    {
        private clsPeople _Person;
        private int _PersonID = -1;

        public int PersonID
        {
            get { return _PersonID; }
        }

        public clsPeople SelectedPersonInfo
        {
            get { return _Person; }
        }
        public  void LoadPersonInfo(int PersonID)
        {
            _Person = clsPeople.Find(PersonID);

            if (_Person == null)
            {
                MessageBox.Show("No Person with PersonID = " + PersonID.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // clsCountry Country = clsCountry.Find(_Person.NationalityCountryID);

            _PersonID = _Person.PersonID;
            lblPersonID.Text = PersonID.ToString();
            lblName.Text = _Person.FirstName + " " + _Person.SecondName + " " + _Person.ThirdName + " " + _Person.LastName;
            lblNationalNo.Text = _Person.NationalNo.ToString();
            lblGender.Text = (_Person.Gender == 0 ? "Male" : "Female");            
            lblDateOfBirth.Text = _Person.DateOfBirth.ToShortDateString();
            lblAddress.Text = _Person.Address.ToString();
            lblPhone.Text = _Person.Phone.ToString();
            lblEmail.Text = _Person.Email.ToString();
            lblCountry.Text = _Person.CountryInfo.CountryName.ToString();
            //lblCountry.Text = _Person.NationalityCountryID.ToString();
            //lblCountry.Text = Country.CountryName.ToString();

            
            string ImagePath = _Person.ImagePath.ToString();

            if (_Person.Gender == 0)
                pbPerson.Image = Properties.Resources.anonymous;
            else
                pbPerson.Image = Properties.Resources.anonymous_woman;

            if (ImagePath != null && ImagePath != "")
            {
               // pbPerson.Image = LoadImageWithoutLock(ImagePath);

                if(File.Exists(ImagePath))
                    pbPerson.ImageLocation = ImagePath;
                else             
                    MessageBox.Show("Could not find this image: = " + ImagePath, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);    

            }
           

        }

        public void LoadPersonInfo(string NationalNo)
        {
            _Person = clsPeople.Find(NationalNo);

            if (_Person == null)
            {
                MessageBox.Show("No Person with National No. = " + NationalNo.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // clsCountry Country = clsCountry.Find(_Person.NationalityCountryID);

            _PersonID = _Person.PersonID;
            lblPersonID.Text = _Person.PersonID.ToString();
            lblName.Text = _Person.FullName.ToString();
            lblNationalNo.Text = _Person.NationalNo.ToString();
            lblGender.Text = (_Person.Gender == 0 ? "Male" : "Female");
            lblDateOfBirth.Text = _Person.DateOfBirth.ToShortDateString();
            lblAddress.Text = _Person.Address.ToString();
            lblPhone.Text = _Person.Phone.ToString();
            lblEmail.Text = _Person.Email.ToString();
            lblCountry.Text = _Person.CountryInfo.CountryName.ToString();
            //lblCountry.Text = _Person.NationalityCountryID.ToString();
            //lblCountry.Text = Country.CountryName.ToString();


            string ImagePath = _Person.ImagePath.ToString();

            if (_Person.Gender == 0)
                pbPerson.Image = Properties.Resources.anonymous;
            else
                pbPerson.Image = Properties.Resources.anonymous_woman;

            if (ImagePath != null && ImagePath != "")
            {
                // pbPerson.Image = LoadImageWithoutLock(ImagePath);

                if (File.Exists(ImagePath))
                    pbPerson.ImageLocation = ImagePath;
                else
                    MessageBox.Show("Could not find this image: = " + ImagePath, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }



        }
        public ctrPersonDetails()
        {
            InitializeComponent();
        }





        private void frmPersonDetails_Load(object sender, EventArgs e)
        {
           
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void llEditPerson_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if(_Person == null)
            {
                MessageBox.Show("There is no person", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            frmAddEditPerson frm = new frmAddEditPerson(_Person.PersonID);
            frm.ShowDialog();
            LoadPersonInfo(_Person.PersonID);
        }
    }
}
