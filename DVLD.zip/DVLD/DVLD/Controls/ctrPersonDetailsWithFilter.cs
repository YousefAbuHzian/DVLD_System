﻿using BussinessLayer;
using FullRealProject.PeopleForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.UserControls
{
    public partial class ctrPersonDetailsWithFilter : UserControl
    {

        // Define a custom event handler delegate with parameters
        public event Action<int> OnPersonSelected;
        // Create a protected method to raise the event with a parameter
        protected virtual void PersonSelected(int PersonID)
        {
            Action<int> handler = OnPersonSelected;
            if (handler != null)
            {
                handler(PersonID); // Raise the event with the parameter
            }
        }


        public int PersonID
        {
            get
            {
                return ctrPersonDetails1.PersonID;
            }        
        }
        public void loadPersonalInfo(int PersonID)
        {
            cbFilter.SelectedIndex = 0;
            tbFilter.Text = PersonID.ToString();
            FindNow();

        }

        private bool _FilterEnabled = true;
        public bool GroupBoxEnabled
        {
            get
            {
                return _FilterEnabled;
            }
            set
            {
                _FilterEnabled = value;
                groupBox1.Enabled = _FilterEnabled;
            }
        }
        private bool _ShowAddPerson = true;
        public bool ShowAddPerson
        {
            get
            {
                return _ShowAddPerson;
            }
            set
            {
                _ShowAddPerson = value;
                btnAddPerson.Visible = _ShowAddPerson;
            }
        }


        public string gettbFilterText
        {
            get
            {
                return tbFilter.Text;
            }
            set { }
        }

        public int getcbFilterSelected
        {
            get { return cbFilter.SelectedIndex; }
        }
        public ctrPersonDetailsWithFilter()
        {
            InitializeComponent();
        }

        private void PersonDetailsWithFilter_Load(object sender, EventArgs e)
        {
            cbFilter.SelectedIndex = 0;
            tbFilter.Focus();
        }  

        private void FindNow()
        {
            switch (cbFilter.Text)
            {
                case "Person ID":

                    ctrPersonDetails1.LoadPersonInfo(int.Parse(tbFilter.Text));
                    break;

                case "National No.":
                    ctrPersonDetails1.LoadPersonInfo(tbFilter.Text);
                    break;

                default:
                    break;
            }

            if (OnPersonSelected != null && GroupBoxEnabled && ctrPersonDetails1.SelectedPersonInfo != null)
                PersonSelected(ctrPersonDetails1.PersonID);

        }
        private void btnGetPerson_Click(object sender, EventArgs e)
        {
            if (!this.ValidateChildren())
            {
                //Here we dont continue becuase the form is not valid
                MessageBox.Show("Some fileds are not valide!, put the mouse over the red icon(s) to see the error", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            FindNow();
        }

        private void btnAddPerson_Click(object sender, EventArgs e)
        {
            frmAddEditPerson frm = new frmAddEditPerson(-1);

            frm.DataBack += Frm_DataBack; 

            frm.ShowDialog();

        }
        private void Frm_DataBack(object sender, int PersonID)
        {
            //throw new NotImplementedException();
            ctrPersonDetails1.LoadPersonInfo(PersonID);
            cbFilter.SelectedIndex = 0;
            tbFilter.Text = PersonID.ToString();
        }
        public void FilterFocus()
        {
            tbFilter.Focus();
        }

        private void tbFilter_KeyPress(object sender, KeyPressEventArgs e)
        {
           // MessageBox.Show("KeyPress fired: " + ((int)e.KeyChar).ToString());
            if (e.KeyChar == (char)Keys.Enter ) // e.KeyChar == (char)13
            {
                btnGetPerson.PerformClick();
            }
            if (cbFilter.SelectedIndex == 0)
            {
                e.Handled = !char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar); // block the input
                
            }
        }

        private void ctrPersonDetails1_Load(object sender, EventArgs e)
        {

        }

        private void cbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            tbFilter.Text = "";
            tbFilter.Focus();
        }

        private void tbFilter_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(tbFilter.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(tbFilter, "This field is required!");
            }
            else
            {
                //e.Cancel = false;
                errorProvider1.SetError(tbFilter, null);
            }
        }
    }
}
