﻿using BussinessLayer;
using FullRealProject.Driving_License_Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.Controls
{
    public partial class ctrLocalDrivingLicenseAppDetails : UserControl
    {

        clsLocalDrivingLicenseApplication _LDLApp;

        private int _LicenseID;

       

        public void LoadLDLAppInfo(int LDLAppID)
        {
            _LDLApp = clsLocalDrivingLicenseApplication.Find(LDLAppID);
            if( _LDLApp == null)
            {
                 MessageBox.Show("Application  is null");
                 return;
            }

            _LicenseID = _LDLApp.GetActiveLicenseID();

            //incase there is license enable the show link.
            llShowLicenseInfo.Enabled = (_LicenseID != -1);

            lblLDLAppID.Text = LDLAppID.ToString();
            lblClassName.Text = _LDLApp.LicenseClassInfo.ClassName;
           // lblClassName.Text = clsLicenseClass.Find(_LDLApp.LicenseClassID).ClassName;
            lblPassedTests.Text = clsLocalDrivingLicenseApplication.GetPassedTestCountByLDLAppID(LDLAppID).ToString();
            ctrApplicationBasicInfo1.LoadApplicationInfo(_LDLApp.ApplicationID);
        }


        public ctrLocalDrivingLicenseAppDetails()
        {
            InitializeComponent();
        }

        private void ctrLocalDrivingLicenseAppDetails_Load(object sender, EventArgs e)
        {

        }

        private void llShowLicenseInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmDriverLicenseInfo frm = new frmDriverLicenseInfo(_LicenseID);
            frm.ShowDialog();
        }
    }
}
