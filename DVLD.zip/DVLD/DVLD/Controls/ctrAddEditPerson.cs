﻿using BussinessLayer;
using FullRealProject.Global_Classes;
using FullRealProject.PeopleForms;
using FullRealProject.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Contracts;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.UserControls
{
    public partial class ctrAddEditPerson : UserControl
    {
        public clsPeople Person2;

        public string txtNationalNo
        {
            get { return tbNationalNo.Text; }

        }

        public TextBox NationalNo
        {
            get { return tbNationalNo; }
            set { tbNationalNo = value; }
        }

        public System.Drawing.Image img
        {
            get { return pbPerson.Image; }
            set { pbPerson.Image = value; }
        }
        public PictureBox pictureBox
        {
            get { return pbPerson; }
            set { pbPerson = value; }
        }

       
        public void _LoadObject(clsPeople Person)
        {

            Person.NationalNo = tbNationalNo.Text.Trim();
            Person.FirstName = tbFirstName.Text.Trim();
            Person.SecondName = tbSecondName.Text.Trim();
            Person.ThirdName = tbThirdName.Text.Trim();
            Person.LastName = tbLastName.Text.Trim();
            Person.DateOfBirth = dtpPerson.Value;
            if (rbMale.Checked)
                Person.Gender = 0;
            else
                Person.Gender = 1;

            Person.Address = tbAddress.Text.Trim();
            if (clsValidation.IsValidEmail(tbEmail.Text) || string.IsNullOrEmpty(tbEmail.Text))
                Person.Email = tbEmail.Text.Trim();
            else
                Person.Email = "-1";


                Person.Phone = tbPhone.Text.Trim();
            if(cbCountries.Text != "")
                Person.NationalityCountryID = clsCountry.Find(cbCountries.Text).CountryID;
            else
                Person.NationalityCountryID = -1;


            if (pbPerson.ImageLocation != null)
            {

                Person.ImagePath = pbPerson.ImageLocation;

                llRemoveImage.Visible = true;
            }
            else
            {
                Person.ImagePath = "";
                llRemoveImage.Visible = false;
            }          

        }

        public void LoadControl( clsPeople  Person2)
        {
            
            tbNationalNo.Text = Person2.NationalNo;
            tbFirstName.Text = Person2.FirstName;
            tbSecondName.Text = Person2.SecondName;
            tbThirdName.Text = Person2.ThirdName;
            tbLastName.Text = Person2.LastName;
            tbAddress.Text = Person2.Address;
            tbEmail.Text = Person2.Email;
            tbPhone.Text = Person2.Phone;
            dtpPerson.Value = Person2.DateOfBirth;
            if (Person2.Gender == 0)
                rbMale.Checked = true;
            else
                rbFemale.Checked = true;
            if(Person2.ImagePath != "")
            {
                pbPerson.ImageLocation = Person2.ImagePath;
                llRemoveImage.Visible = true;
            }
            else
            {
                if (Person2.Gender == 0)
                    pbPerson.Image = Properties.Resources.anonymous;
                else
                    pbPerson.Image = Properties.Resources.anonymous_woman;
                llRemoveImage.Visible = false;
            }

            cbCountries.Text = clsCountry.Find(Person2.NationalityCountryID).CountryName;
            dtpPerson.MaxDate = DateTime.Now.AddYears(-18);
            dtpPerson.Value = dtpPerson.MaxDate;
            dtpPerson.MinDate = DateTime.Now.AddYears(-100);
        }

        
        
        private void _FillComboBoxWithCountries()
        {
            DataTable dt = clsCountry.GetAllCountries();

            foreach(DataRow row in dt.Rows)
            {
                cbCountries.Items.Add(row["CountryName"]);
            }
        }
        public void LoadInfo( )
        {
            _FillComboBoxWithCountries();
            dtpPerson.MaxDate = DateTime.Now.AddYears(-18);
            dtpPerson.Value = dtpPerson.MaxDate;
            dtpPerson.MinDate = DateTime.Now.AddYears(-100);
            cbCountries.SelectedIndex = cbCountries.FindString("Algeria");
            llRemoveImage.Visible = false;
        }
        public ctrAddEditPerson()
        {
            InitializeComponent();
        }

       

        private void ctrAddEditPerson_Load(object sender, EventArgs e)
        {
            LoadInfo();
        }

        private void llSetImage_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            openFileDialog1.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                // Process the selected file
                string selectedFilePath = openFileDialog1.FileName;
                //MessageBox.Show("Selected Image is:" + selectedFilePath);
                
                pbPerson.Load(selectedFilePath);
                llRemoveImage.Visible = true;
                // ...
            }
            
        }

        private void llRemoveImage_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            pbPerson.ImageLocation = null;
            
            if (rbMale.Checked)
                pbPerson.Image = Properties.Resources.anonymous;
            else
                pbPerson.Image = Properties.Resources.anonymous_woman;


                llRemoveImage.Visible = false;
        }

        private void Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(((TextBox)sender).Text.Trim()))
            {
                e.Cancel = true;
                //((TextBox)sender).Focus();
                errorProvider1.SetError((TextBox)sender, "This Feild Cannot be empty!");
            }
            else
            {
                //e.Cancel = false;
                errorProvider1.SetError((TextBox)sender, null);
            }
        }

        private void cbCountries_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(cbCountries.Text))
            {
                e.Cancel = true;
                cbCountries.Focus();
                errorProvider1.SetError(cbCountries, "This Feild Cannot be empty!");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(cbCountries, "");
            }
        }

       

        private void tbNationalNo_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbNationalNo.Text.Trim()))
            {
                e.Cancel = true;
                //tbNationalNo.Focus();
                errorProvider1.SetError(tbNationalNo, "This Feild is Empty or invalid!");
                return;
            }
            else
            {
                //e.Cancel = false;
                errorProvider1.SetError(tbNationalNo, "");
            }
            //if (tbNationalNo.Text.Trim() != )
            //{

            //}
            //else
            //{

            //}
        }

        private void tbPhone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // block the input
            }
        }

        private void tbEmail_Validating(object sender, CancelEventArgs e)
        {
            if(!clsValidation.IsValidEmail(tbEmail.Text) && !string.IsNullOrWhiteSpace(tbEmail.Text))
            {
                e.Cancel= true;
                tbEmail.Focus();
                errorProvider1.SetError(tbEmail, "Email is invalid");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(tbEmail, "");
            }
        }

        private void rbMale_Click(object sender, EventArgs e)
        {
            //change the defualt image to male incase there is no image set.
            if (pbPerson.ImageLocation == null)
                pbPerson.Image = Resources.anonymous;
        }

        private void rbFemale_Click(object sender, EventArgs e)
        {
            if (pbPerson.ImageLocation == null)
                pbPerson.Image = Resources.anonymous_woman;
        }

        private void rbFemale_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rbMale_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
