﻿using BussinessLayer;
using FullRealProject.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.Controls
{
    public partial class ctrDriverLicenseInfo : UserControl
    {
        int _LicenseID;
        clsLicense _License;
        public int LicenseID
        {
            get { return _LicenseID; }
        }
        public clsLicense SelectedLicenseInfo
        {
            get { return _License; }
        }
        public ctrDriverLicenseInfo()
        {
            InitializeComponent();
        }


        
        private void _LoadPersonImage()
        {
            if (_License.DriverInfo.PersonInfo.Gender == 0)
                pictureBox1.Image = Resources.anonymous;
            else
                pictureBox1.Image = Resources.anonymous_woman;
            string ImagePath = _License.DriverInfo.PersonInfo.ImagePath;

            if (ImagePath != "")
                if (File.Exists(ImagePath))
                    pictureBox1.ImageLocation = ImagePath;
                else
                    MessageBox.Show("Image Has been Deleted ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }
       

        public void LoadControlByLicenseID(int LicenseID)
        {

            
            _License = clsLicense.Find(LicenseID);

            
            if (_License == null)
            {
                MessageBox.Show("This License Does Not Exist", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            _LicenseID = _License.LicenseID;

            lblClass.Text = _License.LicenseClassInfo.ClassName;
            lblName.Text = _License.DriverInfo.PersonInfo.FullName;
            lblLicenseID.Text = _License.LicenseID.ToString();
            lblNationalNo.Text = _License.DriverInfo.PersonInfo.NationalNo.ToString();
  
            lblGender.Text = _License.DriverInfo.PersonInfo.Gender == 0 ? "Male" : "Female";
        
            lblIssueDate.Text = _License.IssueDate.ToShortDateString();
            
            lblIssueReason.Text = _License.IssueReasonText.ToString();

            
            lblNotes.Text = _License.Notes == "" ? "No Notes" : _License.Notes.ToString();
            lblIsActive.Text = _License.IsActive ? "Yes" : "No";
            lblDateOfBirth.Text = _License.DriverInfo.PersonInfo.DateOfBirth.ToShortDateString();
            lblDriverID.Text = _License.DriverID.ToString();
            lblExpirationDate.Text = _License.ExpirationDate.ToShortDateString();
            lblIsDetained.Text = clsDetainLicense.GetDetainIDByLicenseID(_License.LicenseID) == -1 ? "No" : "Yes";
            lblIsDetained.Text = _License.IsDetained ? "Yes" : "No";

            _LoadPersonImage();


        }
        private void ctrDriverLicenseInfo_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
