﻿using BussinessLayer;
using FullRealProject.Driving_License_Forms;
using FullRealProject.International_Licenses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.Controls
{
    public partial class ctrDriverLicenses : UserControl
    {
        private int _DriverID;
        private clsDriver _Driver;
        private DataTable _dtDriverLocalLicensesHistory;
        private DataTable _dtDriverInternationalLicensesHistory;
        public ctrDriverLicenses()
        {
            InitializeComponent();
        }

        public void LoadControl(int PersonID)
        {
            _Driver = clsDriver.FindByPersonID(PersonID);
            if (_Driver == null)
            {
                MessageBox.Show("Person With Person ID = " + PersonID + " is Not a Driver", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            _DriverID = _Driver.DriverID;
            _dtDriverLocalLicensesHistory  = clsLicense.GetAllLicensesByPersonID(PersonID);

            dgvLocalLicenses.DataSource = _dtDriverLocalLicensesHistory;

            lblLocalRecordsCount.Text = dgvLocalLicenses.RowCount.ToString();
            if (dgvLocalLicenses.Rows.Count > 0)
            {
                dgvLocalLicenses.Columns[0].HeaderText = "Lic.ID";

                dgvLocalLicenses.Columns[1].HeaderText = "App.ID";

                dgvLocalLicenses.Columns[2].HeaderText = "Class Name";

                dgvLocalLicenses.Columns[3].HeaderText = "Issue Date";

                dgvLocalLicenses.Columns[4].HeaderText = "Expiration Date";

                dgvLocalLicenses.Columns[5].HeaderText = "Is Active";

            }




            _dtDriverInternationalLicensesHistory = clsInternationalLicense.GetAllInternationalLicensesByPersonID(PersonID);
            
            dgvInternationalLicenses.DataSource = _dtDriverInternationalLicensesHistory;
            
            lblInternationalRecordsCount.Text = dgvInternationalLicenses.RowCount.ToString();

            if (dgvInternationalLicenses.Rows.Count > 0)
            {
                dgvInternationalLicenses.Columns[0].HeaderText = "Int.License ID";

                dgvInternationalLicenses.Columns[1].HeaderText = "Application ID";

                dgvInternationalLicenses.Columns[2].HeaderText = "L.License ID";

                dgvInternationalLicenses.Columns[3].HeaderText = "Issue Date";

                dgvInternationalLicenses.Columns[4].HeaderText = "Expiration Date";

                dgvInternationalLicenses.Columns[5].HeaderText = "Is Active";

            }

        }

        private void ctrDriverLicenses_Load(object sender, EventArgs e)
        {

        }

        private void tpLocal_Click(object sender, EventArgs e)
        {

        }
        public void Clear()
        {
            _dtDriverLocalLicensesHistory.Clear();
            _dtDriverInternationalLicensesHistory.Clear();

        }
        private void showLicenseInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(dgvLocalLicenses.Rows.Count == 0 ) { return; }
            int licenseID = Convert.ToInt32(dgvLocalLicenses.CurrentRow.Cells[0].Value);

            frmDriverLicenseInfo frm = new frmDriverLicenseInfo(licenseID);
            frm.ShowDialog();
        }

        private void showInternationalLicenseInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgvInternationalLicenses.Rows.Count == 0) { return; }
            int InternationalLicenseID = Convert.ToInt32(dgvInternationalLicenses.CurrentRow.Cells[0].Value);
            frmDriverInternationalLicenseInfo frm = new frmDriverInternationalLicenseInfo(InternationalLicenseID);
            frm.ShowDialog();
        }
    }
}
