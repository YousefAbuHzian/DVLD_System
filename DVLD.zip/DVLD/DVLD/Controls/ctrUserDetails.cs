﻿using BussinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.UserControls
{
    public partial class ctrUserDetails : UserControl
    {
        clsUser _User;
        private int _UserID;

        public int UserID
        {
            get
            {
                return _UserID; 
            }
        }
        public ctrUserDetails()
        {
            InitializeComponent();
        }

        public void LoadUserInfo(int UserID)
        {
            _User = clsUser.Find(UserID);
            _UserID = UserID;

            if (_User == null)
            {
                MessageBox.Show("No User with UserID = " + UserID.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            ctrPersonDetails1.LoadPersonInfo(_User.PersonID);

            lblUserName.Text = _User.UserName;
            lblUserID.Text = _User.UserID.ToString();
            lblIsActive.Text = (_User.isActive) ? "Yes" : "No";
           
            //if (_User.isActive)
            //{
            //    lblIsActive.Text = "Yes";
            //}
            //else
            //{
            //    lblIsActive.Text = "Yes";

            //}

        }

        private void ctrUserDetails_Load(object sender, EventArgs e)
        {

        }
    }
}
