﻿using BussinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.Controls
{
    public partial class ctrDriverLicenseInfoWithFilter : UserControl
    {
       // public int LicenseID;

        public event Action<int> OnLicenseSelected;

        protected virtual void LicenseSelected(int LicenseID)
        {
            Action<int> handler = OnLicenseSelected;
            if (handler != null)
            {
                handler(LicenseID);
            }
        }
        int _LicenseID = -1;
        
        public int LicenseID
        {
            get { return ctrDriverLicenseInfo1.LicenseID; }
        }

        public clsLicense SelectedLicenseInfo
        { get { return ctrDriverLicenseInfo1.SelectedLicenseInfo; } }

        private bool _FilterEnabled = true;
        public bool EnableFilter
        {
            get
            {
                return _FilterEnabled;
            }
            set
            {
                _FilterEnabled = value;
                groupBox1.Enabled = value;
            }
        }
      

       
        
        public ctrDriverLicenseInfoWithFilter()
        {
            InitializeComponent();
        }

        
        public void LoadLicenseInfo(int LicenseID)
        {


            tbFilter.Text = LicenseID.ToString();
            ctrDriverLicenseInfo1.LoadControlByLicenseID(LicenseID);
            _LicenseID = ctrDriverLicenseInfo1.LicenseID;
            if (OnLicenseSelected != null && EnableFilter)
                // Raise the event with a parameter
                LicenseSelected(_LicenseID);


        }

        

        


        private void btnLoadControl_Click(object sender, EventArgs e)
        {
            if (!this.ValidateChildren())
            {
                //Here we dont continue becuase the form is not valid
                MessageBox.Show("Some fileds are not valide!, put the mouse over the red icon(s) to see the erro", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbFilter.Focus();
                return;

            }
             _LicenseID = Convert.ToInt32(((string)tbFilter.Text).Trim());
            if (!clsLicense.IsExist(_LicenseID))
            {
                MessageBox.Show("This License ID Does Not Exist in The System!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            LoadLicenseInfo(_LicenseID);

            

        }

        public void tbLicenseIDFocus()
        {
            tbFilter.Focus();
        }

        private void tbFilter_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(tbFilter.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(tbFilter, "This field is required!");
            }
            else
            {
                //e.Cancel = false;
                errorProvider1.SetError(tbFilter, null);
            }
        }

        private void ctrDriverLicenseInfoWithFilter_Load(object sender, EventArgs e)
        {

        }

        private void ctrDriverLicenseInfo1_Load(object sender, EventArgs e)
        {

        }

        private void tbFilter_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (e.KeyChar == (char)Keys.Enter)
            {
                btnLoadControl.PerformClick();
                e.Handled = true;
                return;
            }

            e.Handled = !char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        //private void tbFilter_KeyDown(object sender, KeyEventArgs e)
        //{
        //    MessageBox.Show("KeyPress fired: " + ((int)e.KeyCode).ToString());

        //    //if (e.KeyChar == (char)Keys.Enter)
        //    //{
        //    //    btnLoadControl.PerformClick();
        //    //    e.Handled = true;
        //    //    return;
        //    //}
        //    if (e.KeyCode == Keys.Enter)
        //    {
        //        e.SuppressKeyPress = true; // stop ding / default
        //        btnLoadControl.PerformClick();
        //    }

        //}
    }
}
