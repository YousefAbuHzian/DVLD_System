﻿using BussinessLayer;
using FullRealProject.PeopleForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.Controls
{
    public partial class ctrApplicationBasicInfo : UserControl
    {
        clsApplication _App;
        public ctrApplicationBasicInfo()
        {
            InitializeComponent();
        }

        public void LoadApplicationInfo(int ApplicationID)
        {
             _App = clsApplication.Find(ApplicationID);
            if (_App == null )
            {
                MessageBox.Show("Application  is null");
                return;
            }

            lblAppID.Text = _App.ApplicationID.ToString();          
            lblStatus.Text = _App.Status.ToString();
            lblFees.Text = _App.PaidFees.ToString();
            lblType.Text = clsApplicationType.Find(_App.ApplicationTypeID).ApplicationTypeTitle;
            lblApplicant.Text = _App.PersonInfo.FullName;
            lblDate.Text = _App.ApplicationDate.ToShortDateString();
            lblStatusDate.Text = _App.LastStatusDate.ToShortDateString();
            lblCreatedBy.Text = clsUser.Find(_App.CreatedByUserID).UserName;
        }


        private void ctrApplicationBasicInfo_Load(object sender, EventArgs e)
        {

        }

        private void llShowPersonInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmShowDetails frm = new frmShowDetails(_App.ApplicantPersonID);
            frm.ShowDialog();
        }

       
    }
}
