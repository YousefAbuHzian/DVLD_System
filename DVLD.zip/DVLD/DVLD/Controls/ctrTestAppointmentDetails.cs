﻿using BussinessLayer;
using FullRealProject.Global_Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.Controls
{
    public partial class ctrTestAppointmentDetails : UserControl
    {
        public string Trial
        {  
            get { return lblTrial.Text; }

            set {  lblTrial.Text = value; }     
        
        }
        public ctrTestAppointmentDetails()
        {
            InitializeComponent();
        }
        public void LoadControl(int TestTypeID, clsTestAppointment appointment)
        {
            dateTimePicker1.Visible = true;
            lblDate.Visible = false;
            lblLDLAppID.Text = appointment.LDLAppID.ToString();
            clsLocalDrivingLicenseApplication LDLApp = clsLocalDrivingLicenseApplication.Find(appointment.LDLAppID);
            //we compare the current date with the appointment date to set the min date.
            if (DateTime.Compare(DateTime.Now, appointment.AppointmentDate) < 0)
                dateTimePicker1.MinDate = DateTime.Now;
            else
                dateTimePicker1.MinDate = appointment.AppointmentDate;

            dateTimePicker1.Value = appointment.AppointmentDate;

            lblClassName.Text = clsLicenseClass.Find(LDLApp.LicenseClassID).ClassName.ToString();
            lblFees.Text =  appointment.PaidFees.ToString();
            lblDate.Text = appointment.AppointmentDate.ToShortDateString();
            //clsApplication app = clsApplication.Find(LDLApp.ApplicationID);
            //clsPeople person = clsPeople.Find(app.ApplicantPersonID);
            lblFullName.Text = LDLApp.PersonInfo.FullName.ToString();
            
        }

        public void LoadControl(int TestTypeID, clsTestAppointment appointment, bool TakeTest)
        {
            dateTimePicker1.Visible = false ;
            lblDate.Visible = true;
            lblLDLAppID.Text = appointment.LDLAppID.ToString();
            clsLocalDrivingLicenseApplication LDLApp = clsLocalDrivingLicenseApplication.Find(appointment.LDLAppID);

            //dateTimePicker1.Value = appointment.AppointmentDate.ToLocalTime();

            lblClassName.Text = clsLicenseClass.Find(LDLApp.LicenseClassID).ClassName.ToString();
            lblFees.Text = appointment.PaidFees.ToString();
            lblDate.Text = appointment.AppointmentDate.ToShortDateString();
            //clsApplication app = clsApplication.Find(LDLApp.ApplicationID);
            //clsPeople person = clsPeople.Find(app.ApplicantPersonID);
            lblFullName.Text = LDLApp.PersonInfo.FullName;

        }
        public void LoadObj(int TestTypeID, ref clsTestAppointment appointment, int LDLAppID)
        {
            dateTimePicker1.MinDate = DateTime.Now;
            dateTimePicker1.Visible = true;
            lblDate.Visible = false;
            appointment.AppointmentDate = dateTimePicker1.Value;
            lblLDLAppID.Text = LDLAppID.ToString();

            clsLocalDrivingLicenseApplication LDLApp = clsLocalDrivingLicenseApplication.Find(LDLAppID);

            lblClassName.Text = LDLApp.LicenseClassInfo.ClassName.ToString();
            lblFees.Text = clsTestType.Find(TestTypeID).TestTypeFees.ToString();
           // lblFees.Text = "10";
           // clsApplication app = clsApplication.Find(LDLApp.ApplicationID);
           // clsPeople person = clsPeople.Find(app.ApplicantPersonID);
            lblFullName.Text = LDLApp.PersonInfo.FullName;

            //appointment.RetakeTestApplicationID = -1;
            appointment.LDLAppID = LDLAppID;
            appointment.PaidFees = clsTestType.Find(TestTypeID).TestTypeFees;
            appointment.CreatedByUserID = clsGlobal.CurrentUser.UserID;
            appointment.IsLocked = false;
            appointment.TestTypeID = TestTypeID;
            
        }
        
    }
}
