﻿using BussinessLayer;
using FullRealProject.PeopleForms;
using System;
using FullRealProject.Global_Classes;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.UserForms
{
    public partial class frmManageUsers : Form
    {
        private static DataTable _dtAllUsers;
        public frmManageUsers()
        {
            InitializeComponent();
        }

        private void _RefreshLoad()
        {

            
            _dtAllUsers = clsUser.GetAllUsers();
            
            dgvAllUsers.DataSource = _dtAllUsers;
            lblRecordsCount.Text = (dgvAllUsers.RowCount).ToString();

            cbFilter.SelectedIndex = 0;
            tbFilter.Visible = false;
            cbIsActive.Visible = false;
           

        }

        private void frmManageUsers_Load(object sender, EventArgs e)
        {
            _RefreshLoad();
            if (dgvAllUsers.Rows.Count == 0)
                return;
            dgvAllUsers.Columns[0].HeaderText = "User ID";
            dgvAllUsers.Columns[0].Width = 60;

            dgvAllUsers.Columns[1].HeaderText = "Person ID";
            dgvAllUsers.Columns[1].Width = 80;

            dgvAllUsers.Columns[2].HeaderText = "Full Name";
            dgvAllUsers.Columns[2].Width = 300;

            dgvAllUsers.Columns[3].HeaderText = "UserName";
            dgvAllUsers.Columns[3].Width = 90;

            dgvAllUsers.Columns[4].HeaderText = "Is Active";
            dgvAllUsers.Columns[4].Width = 60;


        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            frmAddEditUser frm = new frmAddEditUser(-1);
            frm.ShowDialog();
            _RefreshLoad();
        }

        private void cbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbFilter.SelectedIndex == 0)
            {
                tbFilter.Visible = false;
                cbIsActive.Visible = false;
            }
            else if(cbFilter.SelectedIndex == 5)
            {
                tbFilter.Visible = false;
                cbIsActive.Visible=true;
                cbIsActive.SelectedIndex = 0;
                cbIsActive.Focus();
            }
            else
            {
                tbFilter.Visible = true;
                cbIsActive.Visible=false;
            }
            tbFilter.Text = "";
            tbFilter.Focus();
        }

        private void cbIsActive_SelectedIndexChanged(object sender, EventArgs e)
        {
            string FilterValue = cbIsActive.Text;

            switch (FilterValue)
            {
                case "All":
                    break;
                case "Yes":
                    FilterValue = "1";
                    break;
                case "No":
                    FilterValue = "0";
                    break;
            }

            if (FilterValue == "All")
                _dtAllUsers.DefaultView.RowFilter = "";
            else
                _dtAllUsers.DefaultView.RowFilter = string.Format($"IsActive = {FilterValue}");

            lblRecordsCount.Text = dgvAllUsers.Rows.Count.ToString();


        }

       

        private void tbFilter_TextChanged(object sender, EventArgs e)
        {
            string FilterColumn = "";
            //Map Selected Filter to real Column name 
            switch (cbFilter.Text)
            {
                case "User ID":
                    FilterColumn = "UserID";
                    break;
                case "UserName":
                    FilterColumn = "UserName";
                    break;

                case "Person ID":
                    FilterColumn = "PersonID";
                    break;


                case "Full Name":
                    FilterColumn = "FullName";
                    break;

                default:
                    FilterColumn = "None";
                    break;

            }

            //Reset the filters in case nothing selected or filter value conains nothing.
            if (tbFilter.Text.Trim() == "" || FilterColumn == "None")
            {
                _dtAllUsers.DefaultView.RowFilter = "";
                lblRecordsCount.Text = dgvAllUsers.Rows.Count.ToString();
                return;
            }

            if (FilterColumn != "FullName" && FilterColumn != "UserName")

                _dtAllUsers.DefaultView.RowFilter = string.Format($"[{FilterColumn}] = {tbFilter.Text.Trim()}");
            else
                _dtAllUsers.DefaultView.RowFilter = string.Format($"[{FilterColumn}] LIKE '{tbFilter.Text.Trim()}%'");

            lblRecordsCount.Text = dgvAllUsers.Rows.Count.ToString();

        }

        private void tbFilter_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (cbFilter.Text == "PersonID" || cbFilter.Text == "UserID")
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                {
                    e.Handled = true; // block the input
                }
            }
        }

        private void showDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUserDetails frm = new frmUserDetails(Convert.ToInt32(dgvAllUsers.CurrentRow.Cells[0].Value));
            frm.ShowDialog();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAddEditUser frm = new frmAddEditUser(Convert.ToInt32(dgvAllUsers.CurrentRow.Cells[0].Value));
            frm.ShowDialog();
            _RefreshLoad();
        }

        private void addNewUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAddEditUser frm = new frmAddEditUser(-1);
            frm.ShowDialog();
            _RefreshLoad();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int DeletedUser = Convert.ToInt32(dgvAllUsers.CurrentRow.Cells[0].Value);
            if (MessageBox.Show("Are You sure You want to Delete this user?", "Confirm", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != DialogResult.OK)
            {
                return;
            }
            if (clsGlobal.CurrentUser.UserID == DeletedUser )
            {
                MessageBox.Show("Error Deleting Current User :(", "Error", MessageBoxButtons.OK
                   , MessageBoxIcon.Error);
                return;
            }
            if (clsUser.DeleteUser(DeletedUser))
            {
                MessageBox.Show("User was Deleted Successfully :)", "Information", MessageBoxButtons.OK
                    , MessageBoxIcon.Information);
                _RefreshLoad();
            }
            else
            {
                MessageBox.Show("User was Not Deleted  :(", "Error", MessageBoxButtons.OK
                   , MessageBoxIcon.Error);
            }
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmChangePassword frm = new frmChangePassword(Convert.ToInt32(dgvAllUsers.CurrentRow.Cells[0].Value));
            frm.ShowDialog();
        }

        private void sendEmailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This Feature is NOT Implemented Yet!", "Coming Soon", MessageBoxButtons.OK
                 , MessageBoxIcon.Exclamation);
        }


        private void phoneCallToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This Feature is NOT Implemented Yet!", "Coming Soon", MessageBoxButtons.OK
                , MessageBoxIcon.Exclamation);
        }

        private void dgvAllUsers_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            frmUserDetails frm = new frmUserDetails(Convert.ToInt32(dgvAllUsers.CurrentRow.Cells[0].Value));
            frm.ShowDialog();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
