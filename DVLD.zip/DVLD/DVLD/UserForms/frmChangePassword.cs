﻿using BussinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.UserForms
{
    public partial class frmChangePassword : Form
    {

        int _UserID;
       

        clsUser _User;
        public frmChangePassword(int UserID)
        {
            InitializeComponent();
            _UserID = UserID;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmChangePassword_Load(object sender, EventArgs e)
        {
            _User = clsUser.Find(_UserID);

            if (_User == null)
            {
                //Here we dont continue becuase the form is not valid
                MessageBox.Show("Could not Find User with id = " + _UserID,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();

                return;

            }
            ctrUserDetails1.LoadUserInfo(_UserID);
            
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            if (!this.ValidateChildren())
            {
                //Here we dont continue becuase the form is not valid
                MessageBox.Show("Some fileds are not valide!, put the mouse over the red icon(s) to see the error",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            _User.Password = tbPassword.Text.Trim();


            if(_User.Save())
            {
                MessageBox.Show("Password Updated Successfully :)", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Password was NOT Updated :(", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(((TextBox)sender).Text))
            {
                e.Cancel = true;
                //((TextBox)sender).Focus();
                errorProvider1.SetError((TextBox)sender, "This Feild Cannot be empty!");
            }
            else
            {
               // e.Cancel = false;
                errorProvider1.SetError((TextBox)sender, "");
            }
        }

        private void tbConfirmPassword_Validating(object sender, CancelEventArgs e)
        {
            if (tbConfirmPassword.Text.Trim() != tbPassword.Text.Trim())
            {
                e.Cancel = true;
                //tbConfirmPassword.Focus();
                errorProvider1.SetError(tbConfirmPassword, "Wrong Password");
            }
            else
            {
                //e.Cancel = false;
                errorProvider1.SetError(tbConfirmPassword, "");
            }
        }

        private void tbCurrentPassword_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbCurrentPassword.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(tbCurrentPassword, "This Feild Cannot be empty!");
                return;
            }
            else
            {
                errorProvider1.SetError(tbCurrentPassword, "");
            }
            if (_User.Password != tbPassword.Text.Trim())
            {
                e.Cancel = true;
                errorProvider1.SetError(tbCurrentPassword, "Password is Wrong!");
                return;
            }
            else
            {
                errorProvider1.SetError(tbCurrentPassword, "");
            }

        }

        private void btnClose_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
