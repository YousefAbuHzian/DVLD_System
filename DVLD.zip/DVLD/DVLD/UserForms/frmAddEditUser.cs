﻿using BussinessLayer;
using FullRealProject.PeopleForms;
using FullRealProject.UserControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Remoting.Messaging;


namespace FullRealProject.UserForms
{
    public partial class frmAddEditUser : Form
    {
        private int _UserID;
        public clsUser _User;

        public enum enMode { AddNew = 0, Update = 1 };
        public enMode Mode ;


        public frmAddEditUser(int UserID)
        {
            InitializeComponent(); 
            _UserID = UserID; 
            if (_UserID == -1)
                Mode = enMode.AddNew;
            else
                Mode = enMode.Update;

        }

        private void _LoadForm()
        {

            if (Mode == enMode.AddNew)
            {
                lblAddEdit.Text = "Add New User";
                this.Text = "Add New User";
                tpLoginInfo.Enabled = false;
                _User = new clsUser();
                ctrPersonDetailsWithFilter1.FilterFocus();
                return;
            }

            lblAddEdit.Text = "Update User";
            this.Text = "Update User";
            tpLoginInfo.Enabled = true;
            btnSave.Enabled = true;

            _User = clsUser.Find(_UserID);
            ctrPersonDetailsWithFilter1.GroupBoxEnabled = false;
            if (_User == null)
            {
                MessageBox.Show("No User with ID = " + _User, "User Not Found", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.Close();

                return;
            }

            lblUserID.Text = _UserID.ToString();
            tbUserName.Text = _User.UserName;
            tbPassword.Text = _User.Password;
            tbConfirmPassword.Text = _User.Password;
            chkIsActive.Checked = (_User.isActive);

            ctrPersonDetailsWithFilter1.loadPersonalInfo(_User.PersonID);
        }

        private void frmAddEditUser_Load(object sender, EventArgs e)
        {
            _LoadForm();
        }

        
       
        private void btnNext_Click(object sender, EventArgs e)
        {
            if(Mode == enMode.Update)
            {
                btnSave.Enabled = true;
                tpLoginInfo.Enabled = true;
                tabControl1.SelectedTab = tabControl1.TabPages["tpLoginInfo"];
                return;
            }

            if (ctrPersonDetailsWithFilter1.PersonID != -1)
            {
                if (clsUser.IsPersonUser(ctrPersonDetailsWithFilter1.PersonID))
                {
                    MessageBox.Show("Selected Person is already a user, choose another one.", "Select another Person", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    ctrPersonDetailsWithFilter1.FilterFocus();
                }
                else
                {
                    btnSave.Enabled = true;
                    tpLoginInfo.Enabled = true;
                    tabControl1.SelectedTab = tabControl1.TabPages["tpLoginInfo"];
                }

            }
            else
            {
                MessageBox.Show("Please Select a Person", "Select a Person", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ctrPersonDetailsWithFilter1.FilterFocus();
            }
        }

        
        private void tbConfirmPassword_Validating(object sender, CancelEventArgs e)
        {
            if (tbConfirmPassword.Text.Trim() != tbPassword.Text.Trim())
            {
                e.Cancel = true;
                //tbConfirmPassword.Focus();
                errorProvider1.SetError(tbConfirmPassword, "Wrong Password");
            }
            else
            {
                //e.Cancel = false;
                errorProvider1.SetError(tbConfirmPassword, "");
            }
        }

        

        private bool _LoadUserObj()
        {
            

            _User.PersonID = ctrPersonDetailsWithFilter1.PersonID;
            _User.UserName = tbUserName.Text.Trim();
            _User.Password = tbPassword.Text.Trim();
            _User.isActive = chkIsActive.Checked;
            return true;

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!this.ValidateChildren())
            {
                //Here we dont continue becuase the form is not valid
                MessageBox.Show("Some fileds are not valide!, put the mouse over the red icon(s) to see the erro",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;

            }

            if (Mode == enMode.AddNew && clsUser.IsPersonUser(ctrPersonDetailsWithFilter1.PersonID))
            {
                MessageBox.Show("Selected Person is already a user, choose another one.", "Select another Person", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ctrPersonDetailsWithFilter1.FilterFocus();
            }

            _LoadUserObj();
            
            if(_User.Save())
            {
                MessageBox.Show("User was Saved Successfully :)", "info", MessageBoxButtons.OK
                    , MessageBoxIcon.Information);
                Mode = enMode.Update;
                lblAddEdit.Text = "Update User";
                lblUserID.Text = _User.UserID.ToString();
                this.Text = "Update User";
                ctrPersonDetailsWithFilter1.GroupBoxEnabled = false;

            }
            else
            {
                MessageBox.Show("User was NOT Saved :(", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void tbUserName_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbUserName.Text.Trim()))
            {
                e.Cancel = true;
                // ((TextBox)sender).Focus();
                errorProvider1.SetError(tbUserName, "This Feild Cannot be empty!");
                return;
            }
            else
            {
                //  e.Cancel = false;
                errorProvider1.SetError(tbUserName, "");
            }
            if (Mode == enMode.AddNew)
            {
                if (clsUser.IsExist(tbUserName.Text.Trim()))
                {
                    e.Cancel = true;
                    errorProvider1.SetError(tbUserName, "username is used by another user");
                }
                else
                {
                    errorProvider1.SetError(tbUserName, null);
                }
                
            }
            else
            {
                if (_User.UserName != tbUserName.Text.Trim())
                {
                    if (clsUser.IsExist(tbUserName.Text.Trim()))
                    {
                        e.Cancel = true;
                        errorProvider1.SetError(tbUserName, "username is used by another user");
                        return;
                    }
                    else
                    {
                        errorProvider1.SetError(tbUserName, null);
                    }
                }
            }

        }

        private void frmAddEditUser_Activated(object sender, EventArgs e)
        {
            ctrPersonDetailsWithFilter1.FilterFocus();
        }

        private void ctrPersonDetailsWithFilter1_OnPersonSelected(int obj)
        {
            if (Mode == enMode.AddNew && clsUser.IsPersonUser(ctrPersonDetailsWithFilter1.PersonID))
            {
                MessageBox.Show("Selected Person is already a user, choose another one.", "Select another Person", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ctrPersonDetailsWithFilter1.FilterFocus();
            }
        }

        private void tbPassword_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(tbPassword.Text.Trim()))
            {
                e.Cancel = true;
                //tbConfirmPassword.Focus();
                errorProvider1.SetError(tbPassword, "This Feild Cannot be Empty!");
            }
            else
            {
                //e.Cancel = false;
                errorProvider1.SetError(tbPassword, "");
            }
        }

        private void tabControl1_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (tabControl1.SelectedTab == tpLoginInfo)
            {
                if (Mode == enMode.Update)
                {
                    btnSave.Enabled = true;
                    tpLoginInfo.Enabled = true;
                    tabControl1.SelectedTab = tabControl1.TabPages["tpLoginInfo"];
                    return;
                }

                if (ctrPersonDetailsWithFilter1.PersonID != -1)
                {
                    if (clsUser.IsPersonUser(ctrPersonDetailsWithFilter1.PersonID))
                    {
                        MessageBox.Show("Selected Person is already a user, choose another one.", "Select another Person", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        ctrPersonDetailsWithFilter1.FilterFocus();
                    }
                    else
                    {
                        btnSave.Enabled = true;
                        tpLoginInfo.Enabled = true;
                        tabControl1.SelectedTab = tabControl1.TabPages["tpLoginInfo"];
                    }

                }
                else
                {
                    MessageBox.Show("Please Select a Person", "Select a Person", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    ctrPersonDetailsWithFilter1.FilterFocus();
                    tabControl1.SelectedTab = tpPersonInfo;
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
