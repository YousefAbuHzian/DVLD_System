﻿using BussinessLayer;
using FullRealProject.Driving_License_Forms;
using FullRealProject.License_Application_Forms;
using FullRealProject.PeopleForms;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.LocalLicense_Application_Forms
{
    public partial class frmManageLocalDrivingLicenseApplications : Form
    {
        private DataTable _dtAllLocalDrivingLicenseApplications;
        public frmManageLocalDrivingLicenseApplications()
        {
            InitializeComponent();
        }

        private void _RefreshLoad()
        {

            
            _dtAllLocalDrivingLicenseApplications = clsLocalDrivingLicenseApplication.GetManageLocalDrivingLicenseApplications();
            
            
             dgvAllLDLApplications.DataSource = _dtAllLocalDrivingLicenseApplications;
             lblRecordsCount.Text = (dgvAllLDLApplications.RowCount).ToString();
            
            
            //showApplicationDetailsToolStripMenuItem.Enabled = false;
            //editApplicationToolStripMenuItem.Enabled = false;
            //cancelApplicationToolStripMenuItem.Enabled = false;
            //deleteApplicationToolStripMenuItem.Enabled = false;
            //scheduleTestsToolStripMenuItem.Enabled = false;
            //issueDrivingLicenseFirstTimeToolStripMenuItem.Enabled = false;
            //showLicenseToolStripMenuItem.Enabled = false;
            //showPersonLicenseHistioryToolStripMenuItem.Enabled = false;
            //scheduleVisionTestToolStripMenuItem.Enabled = false;
            //schedulePracticalTestToolStripMenuItem.Enabled = false;
            //scheduleWrittenTestToolStripMenuItem.Enabled = false;


           
            //dgvAllLDLApplications.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //dgvAllLDLApplications.MultiSelect = false;
            //dgvAllLDLApplications.ContextMenuStrip = contextMenuStrip1; // let WinForms show it automatically


        }



        private void frmManageLocalDrivingLicenseApplications_Load(object sender, EventArgs e)
        {
            _RefreshLoad();

            cbFilter.SelectedIndex = 0;
            tbFilter.Visible = false;

            if (dgvAllLDLApplications.Rows.Count == 0)
                return;
            dgvAllLDLApplications.Columns[0].HeaderText = "L.D.L.AppID";

            dgvAllLDLApplications.Columns[1].HeaderText = "Driving Class";

            dgvAllLDLApplications.Columns[2].HeaderText = "National No.";

            dgvAllLDLApplications.Columns[3].HeaderText = "Full Name";

            dgvAllLDLApplications.Columns[4].HeaderText = "Application Date";

            dgvAllLDLApplications.Columns[5].HeaderText = "Passed Tests";

           
        }

        private void btnAddLDLApp_Click(object sender, EventArgs e)
        {
            frmNewLocalLicenseApplication frm = new frmNewLocalLicenseApplication(-1);
            frm.ShowDialog();
            _RefreshLoad();
        }

        private void cbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbFilter.SelectedIndex == 0)
            {
                tbFilter.Visible = false;
            }
            else
            {
                tbFilter.Visible = true;
                tbFilter.Text = "";
                tbFilter.Focus();
            }
            _dtAllLocalDrivingLicenseApplications.DefaultView.RowFilter = "";
            lblRecordsCount.Text = dgvAllLDLApplications.Rows.Count.ToString();
        }

       

        private void tbFilter_TextChanged(object sender, EventArgs e)
        {
            string FilterColumn = "";
            //Map Selected Filter to real Column name 
            switch (cbFilter.Text)
            {

                case "L.D.L.AppID":
                    FilterColumn = "L.D.L.AppID";
                    break;

                case "National No.":
                    FilterColumn = "National No";
                    break;


                case "Full Name":
                    FilterColumn = "FullName";
                    break;

                case "Status":
                    FilterColumn = "Status";
                    break;

                default:
                    FilterColumn = "None";
                    break;

            }

            //Reset the filters in case nothing selected or filter value conains nothing.
            if (tbFilter.Text.Trim() == "" || FilterColumn == "None")
            {
                _dtAllLocalDrivingLicenseApplications.DefaultView.RowFilter = "";
                lblRecordsCount.Text = dgvAllLDLApplications.Rows.Count.ToString();
                return;
            }


            if (FilterColumn == "L.D.L.AppID")
                //in this case we deal with integer not string.
                _dtAllLocalDrivingLicenseApplications.DefaultView.RowFilter = string.Format("[{0}] = {1}", FilterColumn, tbFilter.Text.Trim());
            else
                _dtAllLocalDrivingLicenseApplications.DefaultView.RowFilter = string.Format("[{0}] LIKE '{1}%'", FilterColumn, tbFilter.Text.Trim());

            lblRecordsCount.Text = dgvAllLDLApplications.Rows.Count.ToString();

        }

        private void tbFilter_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (cbFilter.Text == "L.D.L.AppID")
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                {
                    e.Handled = true; // block the input
                }
            }
        }

        private void cancelApplicationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int LDLAppID = Convert.ToInt32(dgvAllLDLApplications.CurrentRow.Cells[0].Value);
            if(MessageBox.Show("Are You Sure You Want To Cancel This Applicationn", "Confirm", 
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                if(clsLocalDrivingLicenseApplication.CancelApplication(LDLAppID))
                {
                    MessageBox.Show("Application Cancelled", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                    MessageBox.Show("Application was NOT Cancelled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            _RefreshLoad();
        }

        private void editApplicationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int LDLAppID = Convert.ToInt32(dgvAllLDLApplications.CurrentRow.Cells[0].Value);
            frmNewLocalLicenseApplication frm = new frmNewLocalLicenseApplication(LDLAppID);
            frm.ShowDialog();
            _RefreshLoad();
        }

        private void showApplicationDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmApplicationDetails frm = new frmApplicationDetails(Convert.ToInt32(dgvAllLDLApplications.CurrentRow.Cells[0].Value));
            frm.ShowDialog();
        }



        //private void dgvAllLDLApplications_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        //{
        //    if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
        //    {
        //        // Right-click
        //        if (e.Button == MouseButtons.Right)
        //        {
        //            // Clear previous selection
        //            dgvAllLDLApplications.ClearSelection();
        //            // Select the row under the cursor
        //            dgvAllLDLApplications.Rows[e.RowIndex].Selected = true;
        //            dgvAllLDLApplications.CurrentCell = dgvAllLDLApplications.Rows[e.RowIndex].Cells[e.ColumnIndex];
        //            contextMenuStrip1.Show(Cursor.Position);

        //            int LDLAppID = Convert.ToInt32(dgvAllLDLApplications.CurrentRow.Cells[0].Value);
        //            // MessageBox.Show(dgvAllLDLApplications.CurrentRow.Cells["Passed Tests"].Value.ToString());

        //            string SelectedStatus = dgvAllLDLApplications.CurrentRow.Cells["Status"].Value.ToString();
        //            if (SelectedStatus == "Completed")
        //            {
        //                showApplicationDetailsToolStripMenuItem.Enabled = true;
        //                showLicenseToolStripMenuItem.Enabled = true;
        //                showPersonLicenseHistioryToolStripMenuItem.Enabled = true;
        //                // 
        //                // FALSE
        //                editApplicationToolStripMenuItem.Enabled = false;
        //                cancelApplicationToolStripMenuItem.Enabled = false;
        //                deleteApplicationToolStripMenuItem.Enabled = false;
        //                scheduleTestsToolStripMenuItem.Enabled = false;
        //                issueDrivingLicenseFirstTimeToolStripMenuItem.Enabled = false;

        //            }
        //            else if(SelectedStatus == "Cancelled")
        //            {
        //                showApplicationDetailsToolStripMenuItem.Enabled = true;
        //                showPersonLicenseHistioryToolStripMenuItem.Enabled = true;
        //                deleteApplicationToolStripMenuItem.Enabled = true;
        //                // FALSE

        //                editApplicationToolStripMenuItem.Enabled = false;
        //                cancelApplicationToolStripMenuItem.Enabled = false;
        //                scheduleTestsToolStripMenuItem.Enabled = false;
        //                issueDrivingLicenseFirstTimeToolStripMenuItem.Enabled = false;
        //                showLicenseToolStripMenuItem.Enabled = false;
        //            }
        //            else
        //            {
        //                showApplicationDetailsToolStripMenuItem.Enabled = true;
        //                editApplicationToolStripMenuItem.Enabled = true;
        //                cancelApplicationToolStripMenuItem.Enabled = true;
        //                deleteApplicationToolStripMenuItem.Enabled = true;
        //                scheduleTestsToolStripMenuItem.Enabled = true;
        //                showPersonLicenseHistioryToolStripMenuItem.Enabled = true;
        //                // FALSE
        //                issueDrivingLicenseFirstTimeToolStripMenuItem.Enabled = false;
        //                showLicenseToolStripMenuItem.Enabled = false;  

        //                int PassedTests = Convert.ToInt32(dgvAllLDLApplications.CurrentRow.Cells["Passed Tests"].Value);

        //                if (PassedTests == 0)
        //                {
        //                    scheduleVisionTestToolStripMenuItem.Enabled = true;
        //                    scheduleWrittenTestToolStripMenuItem.Enabled = false;
        //                    schedulePracticalTestToolStripMenuItem.Enabled = false;

        //                }
        //                else if (PassedTests == 1)
        //                {
        //                    scheduleVisionTestToolStripMenuItem.Enabled = false;
        //                    scheduleWrittenTestToolStripMenuItem.Enabled = true;
        //                    schedulePracticalTestToolStripMenuItem.Enabled = false;
        //                }
        //                else if(PassedTests == 2)
        //                {
        //                    scheduleVisionTestToolStripMenuItem.Enabled = false;
        //                    scheduleWrittenTestToolStripMenuItem.Enabled = false;
        //                    schedulePracticalTestToolStripMenuItem.Enabled = true;
        //                }
        //                else if(PassedTests == 3)
        //                {
        //                    issueDrivingLicenseFirstTimeToolStripMenuItem.Enabled = true;
        //                    scheduleTestsToolStripMenuItem.Enabled = false;
        //                }
        //            }


        //        }
        //        // Left-click
        //        else if (e.Button == MouseButtons.Left)
        //        {
        //        }
        //    }
        //}
        private void dgvAllLDLApplications_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && e.RowIndex >= 0)
            {
                dgvAllLDLApplications.ClearSelection();
                dgvAllLDLApplications.Rows[e.RowIndex].Selected = true;
                dgvAllLDLApplications.CurrentCell = dgvAllLDLApplications.Rows[e.RowIndex].Cells[e.ColumnIndex];
            }
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            if (dgvAllLDLApplications.SelectedRows.Count == 0)
            {
                e.Cancel = true; // no row selected
                return;
            }

            var row = dgvAllLDLApplications.SelectedRows[0];
            string status = row.Cells["Status"].Value?.ToString();
            int passedTests = Convert.ToInt32(row.Cells["Passed Tests"].Value ?? 0);
            int LDLAppID = (int)row.Cells[0].Value;
            clsLocalDrivingLicenseApplication LDLApp =
                clsLocalDrivingLicenseApplication.Find(LDLAppID);

            bool LicenseExists = LDLApp.IsLicenseIssued();


            issueDrivingLicenseFirstTimeToolStripMenuItem.Enabled = (passedTests == 3) && status == "New";
            showLicenseToolStripMenuItem.Enabled = LicenseExists;
            editApplicationToolStripMenuItem.Enabled = status == "New";
            scheduleTestsToolStripMenuItem.Enabled = status == "New" && passedTests != 3;
            cancelApplicationToolStripMenuItem.Enabled = status == "New";
            deleteApplicationToolStripMenuItem.Enabled = status == "New";

            if (scheduleTestsToolStripMenuItem.Enabled)
            {
                //To Allow Schdule vision test, Person must not passed the same test before.
                scheduleVisionTestToolStripMenuItem.Enabled = passedTests == 0;

                //To Allow Schdule written test, Person must pass the vision test and must not passed the same test before.
                scheduleWrittenTestToolStripMenuItem.Enabled = passedTests == 1;

                //To Allow Schdule steet test, Person must pass the vision * written tests, and must not passed the same test before.
                schedulePracticalTestToolStripMenuItem.Enabled = passedTests == 2;

            }



            //// Reset (safe defaults)
            //showApplicationDetailsToolStripMenuItem.Enabled = false;
            //showLicenseToolStripMenuItem.Enabled = false;
            //showPersonLicenseHistioryToolStripMenuItem.Enabled = false;
            //editApplicationToolStripMenuItem.Enabled = false;
            //cancelApplicationToolStripMenuItem.Enabled = false;
            //deleteApplicationToolStripMenuItem.Enabled = false;
            //scheduleTestsToolStripMenuItem.Enabled = false;
            //issueDrivingLicenseFirstTimeToolStripMenuItem.Enabled = false;
            //scheduleVisionTestToolStripMenuItem.Enabled = false;
            //scheduleWrittenTestToolStripMenuItem.Enabled = false;
            //schedulePracticalTestToolStripMenuItem.Enabled = false;

            //if (status == "Completed")
            //{
            //    showApplicationDetailsToolStripMenuItem.Enabled = true;
            //    showLicenseToolStripMenuItem.Enabled = true;
            //    showPersonLicenseHistioryToolStripMenuItem.Enabled = true;
            //}
            //else if (status == "Cancelled")
            //{
            //    showApplicationDetailsToolStripMenuItem.Enabled = true;
            //    showPersonLicenseHistioryToolStripMenuItem.Enabled = true;
            //    deleteApplicationToolStripMenuItem.Enabled = true;
            //}
            //else
            //{
            //    showApplicationDetailsToolStripMenuItem.Enabled = true;
            //    editApplicationToolStripMenuItem.Enabled = true;
            //    cancelApplicationToolStripMenuItem.Enabled = true;
            //    deleteApplicationToolStripMenuItem.Enabled = true;
            //    scheduleTestsToolStripMenuItem.Enabled = true;
            //    showPersonLicenseHistioryToolStripMenuItem.Enabled = true;

            //    if (passedTests == 0)
            //        scheduleVisionTestToolStripMenuItem.Enabled = true;
            //    else if (passedTests == 1)
            //        scheduleWrittenTestToolStripMenuItem.Enabled = true;
            //    else if (passedTests == 2)
            //        schedulePracticalTestToolStripMenuItem.Enabled = true;
            //    else if (passedTests == 3)
            //    {
            //        issueDrivingLicenseFirstTimeToolStripMenuItem.Enabled = true;
            //        scheduleTestsToolStripMenuItem.Enabled = false;
            //    }
            //}
        }



        //private void dgvAllLDLApplications_MouseDown(object sender, MouseEventArgs e)
        //{
        //    if (e.Button != MouseButtons.Right) return;

        //    var hit = dgvAllLDLApplications.HitTest(e.X, e.Y);
        //    if (hit.RowIndex < 0) return; // ignore header/empty space

        //    dgvAllLDLApplications.ClearSelection();
        //    int row = hit.RowIndex;
        //    int col = hit.ColumnIndex >= 0 ? hit.ColumnIndex : 0;
        //    dgvAllLDLApplications.Rows[row].Selected = true;
        //    dgvAllLDLApplications.CurrentCell = dgvAllLDLApplications.Rows[row].Cells[col];

        //    contextMenuStrip1.Show(dgvAllLDLApplications, e.Location);
        //}

        private void scheduleVisionTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVisionTest frm = new frmVisionTest(1,Convert.ToInt32(dgvAllLDLApplications.CurrentRow.Cells[0].Value));
            frm.ShowDialog();
            _RefreshLoad();
        }

        private void scheduleWrittenTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVisionTest frm = new frmVisionTest(2, Convert.ToInt32(dgvAllLDLApplications.CurrentRow.Cells[0].Value));
            frm.ShowDialog();
            _RefreshLoad();
        }

        private void schedulePracticalTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVisionTest frm = new frmVisionTest(3, Convert.ToInt32(dgvAllLDLApplications.CurrentRow.Cells[0].Value));
            frm.ShowDialog();
            _RefreshLoad();
            
        }

        private void deleteApplicationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure do want to delete this application?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                return;

            int LocalDrivingLicenseApplicationID = (int)dgvAllLDLApplications.CurrentRow.Cells[0].Value;

            clsLocalDrivingLicenseApplication LocalDrivingLicenseApplication =
                clsLocalDrivingLicenseApplication.Find(LocalDrivingLicenseApplicationID);

            if (LocalDrivingLicenseApplication != null)
            {
                if (LocalDrivingLicenseApplication.Delete())
                {
                    MessageBox.Show("Application Deleted Successfully.", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //refresh the form again.
                    _RefreshLoad();
                }
                else
                {
                    MessageBox.Show("Could not delete applicatoin, other data depends on it.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void issueDrivingLicenseFirstTimeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmIssueDrivingLicnese frm = new frmIssueDrivingLicnese(Convert.ToInt32(dgvAllLDLApplications.CurrentRow.Cells[0].Value));
            frm.ShowDialog();
            _RefreshLoad();
        }

        private void showLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int LDLAppID = Convert.ToInt32(dgvAllLDLApplications.CurrentRow.Cells[0].Value);
            clsLocalDrivingLicenseApplication LDLApp =
                clsLocalDrivingLicenseApplication.Find(LDLAppID);

            int LicenseID = clsLocalDrivingLicenseApplication.Find(
               LDLAppID).GetActiveLicenseID();

            if (LicenseID != -1)
            {
                frmShowDetails frm = new frmShowDetails(LicenseID);
                frm.ShowDialog();

            }
            else
            {
                MessageBox.Show("No License Found!", "No License", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

        }

        private void showPersonLicenseHistioryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmShowPersonLicenseHistory frm = new frmShowPersonLicenseHistory(dgvAllLDLApplications.CurrentRow.Cells["National No"].Value.ToString());
            frm.ShowDialog();
            _RefreshLoad();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
