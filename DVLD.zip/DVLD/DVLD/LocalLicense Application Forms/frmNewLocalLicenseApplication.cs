﻿using BussinessLayer;
using System;
using FullRealProject.Global_Classes;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace FullRealProject.License_Application_Forms
{
    public partial class frmNewLocalLicenseApplication : Form
    {
        public enum enMode { AddNew = 0, Update = 1 };
        public enMode Mode;

        public clsLocalDrivingLicenseApplication _LDLApp;
        int _SelectedPersonID = -1;
        private int _LDLAppID;

        public frmNewLocalLicenseApplication(int LocalLicenseApplicationID)
        {
            InitializeComponent();
            _LDLAppID = LocalLicenseApplicationID;
            if(LocalLicenseApplicationID == -1)
                Mode = enMode.AddNew;
            else 
                Mode = enMode.Update;
        }

        private void _LoadForm()
        {
            DataTable dt = clsLicenseClass.GetAllLicenseClasses();
            foreach(DataRow row in dt.Rows)
            {
                cbLicenseClasses.Items.Add(row["ClassName"]);
            }
            
            if (Mode == enMode.AddNew)
            {
                cbLicenseClasses.SelectedIndex = 2;
                lblNewLDLApplication.Text = "Add New local Driving License Application";
                this.Text = "New Local Driving License application";
                lblApplicationDate.Text = DateTime.Now.ToShortDateString();
                lblCreatedBy.Text = clsGlobal.CurrentUser.UserName;
                _LDLApp = new clsLocalDrivingLicenseApplication();
                ctrPersonDetailsWithFilter1.FilterFocus();
                tpApplicationInfo.Enabled = false;
                lblFees.Text = clsApplicationType.Find((int)clsApplication.enApplicationType.NewDrivingLicense).ApplicationFees.ToString();
                return;
            }


            tpApplicationInfo.Enabled = true;
            btnSave.Enabled = true;
            _LDLApp = clsLocalDrivingLicenseApplication.Find(_LDLAppID);
            if (_LDLApp == null)
            {
                MessageBox.Show("_ldlApp is null");
                this.Close();
                return;
            }
            
            
            ctrPersonDetailsWithFilter1.loadPersonalInfo(_LDLApp.ApplicantPersonID);
            lblLDLApplicationID.Text = _LDLApp.LocalDrivingLicenseApplicationID.ToString();
            lblApplicationDate.Text = _LDLApp.ApplicationDate.ToString();
            cbLicenseClasses.SelectedIndex = cbLicenseClasses.FindString(_LDLApp.LicenseClassInfo.ClassName);
            lblCreatedBy.Text = _LDLApp.CreatedByUserInfo.UserName;
            lblFees.Text = _LDLApp.PaidFees.ToString();

            lblNewLDLApplication.Text = "Update Local Driving License Application";
            this.Text = "Update Local Driving License Application";
            ctrPersonDetailsWithFilter1.GroupBoxEnabled = false;
        }

        private void frmNewLocalLicenseApplication_Load(object sender, EventArgs e)
        {
            _LoadForm();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (Mode == enMode.Update)
            {
                btnSave.Enabled = true;
                tpApplicationInfo.Enabled = true;
                tabControl1.SelectedTab = tabControl1.TabPages["tpApplicationInfo"];
                return;
            }
            //incase of add new mode.
            if (ctrPersonDetailsWithFilter1.PersonID != -1)
            {

                btnSave.Enabled = true;
                tpApplicationInfo.Enabled = true;
                tabControl1.SelectedTab = tabControl1.TabPages["tpApplicationInfo"];

            }

            else

            {
                MessageBox.Show("Please Select a Person", "Select a Person", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ctrPersonDetailsWithFilter1.FilterFocus();
            }
        }

        

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private bool IsAllowed(int MinAllowedAge, DateTime dt)
        {
            DateTime isAllowed = dt.AddYears(MinAllowedAge);

            return (isAllowed < DateTime.Now);

        }

        

       

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!this.ValidateChildren())
            {
                //Here we dont continue becuase the form is not valid
                MessageBox.Show("Some fileds are not valide!, put the mouse over the red icon(s) to see the erro", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;

            }
            int LicenseClassID = clsLicenseClass.Find(cbLicenseClasses.Text.Trim()).LicenseClassID;
            int MinAllowedAge = clsLicenseClass.Find(LicenseClassID).MinimumAllowedAge; 
            DateTime dob = clsPeople.Find(_SelectedPersonID).DateOfBirth;

            if (!IsAllowed(MinAllowedAge, dob))
            {
                MessageBox.Show("Person's Age is Not Allowed to this License");
                return ;
            }
            if (clsLocalDrivingLicenseApplication.PersonWithSameLicenseClass(_SelectedPersonID, LicenseClassID))
            {
                MessageBox.Show("This Person Already Has a Driving License With the Same Class",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return ;
            }

            _LDLApp.ApplicantPersonID = ctrPersonDetailsWithFilter1.PersonID;
            if (Mode == enMode.AddNew)
            {
                _LDLApp.ApplicationDate = DateTime.Now;
            }
            
            _LDLApp.ApplicationTypeID = (int)clsApplication.enApplicationType.NewDrivingLicense;
            _LDLApp.Status = clsApplication.enStatus.New;
            _LDLApp.LastStatusDate = DateTime.Now;
            _LDLApp.PaidFees = Convert.ToDecimal(lblFees.Text.Trim());
            _LDLApp.CreatedByUserID = clsGlobal.CurrentUser.UserID;
            _LDLApp.LicenseClassID = LicenseClassID;



            if (_LDLApp.Save())
            {
                MessageBox.Show("Local Driving License Application was Saved successfully");
                Mode = enMode.Update;
                lblNewLDLApplication.Text = "Update Local Driving License Application";
                lblLDLApplicationID.Text = _LDLApp.LocalDrivingLicenseApplicationID.ToString();
                ctrPersonDetailsWithFilter1.GroupBoxEnabled = false;
            }
            else
            {
                MessageBox.Show("Local Driving License Application was NOT Saved");
            }
        }

        private void ctrPersonDetailsWithFilter1_OnPersonSelected(int obj)
        {
            _SelectedPersonID = obj;
        }

        private void frmNewLocalLicenseApplication_Activated(object sender, EventArgs e)
        {
            ctrPersonDetailsWithFilter1.FilterFocus();
        }

        private void tpApplicationInfo_Click(object sender, EventArgs e)
        {

        }

        private void tabControl1_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (tabControl1.SelectedTab == tpApplicationInfo)
            {
                if (Mode == enMode.Update)
                {
                    btnSave.Enabled = true;
                    tpApplicationInfo.Enabled = true;
                    tabControl1.SelectedTab = tabControl1.TabPages["tpApplicationInfo"];
                    return;
                }
                //incase of add new mode.
                if (ctrPersonDetailsWithFilter1.PersonID != -1)
                {

                    btnSave.Enabled = true;
                    tpApplicationInfo.Enabled = true;
                    tabControl1.SelectedTab = tabControl1.TabPages["tpApplicationInfo"];

                }

                else

                {
                    MessageBox.Show("Please Select a Person", "Select a Person", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    ctrPersonDetailsWithFilter1.FilterFocus();
                    btnSave.Enabled = false;
                    tpApplicationInfo.Enabled = false;
                    tabControl1.SelectedTab = tpPersonalInfo;
                }
            }
        }
    }
}
