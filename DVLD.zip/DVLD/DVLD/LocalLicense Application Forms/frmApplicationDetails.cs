﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.LocalLicense_Application_Forms
{
    public partial class frmApplicationDetails : Form
    {
        int _LDLAppID;
        public frmApplicationDetails(int LDLAppID)
        {
            InitializeComponent();
            _LDLAppID = LDLAppID;
        }

        

        private void frmApplicationDetails_Load(object sender, EventArgs e)
        {
            ctrLocalDrivingLicenseAppDetails1.LoadLDLAppInfo(_LDLAppID);
        }
    }
}
