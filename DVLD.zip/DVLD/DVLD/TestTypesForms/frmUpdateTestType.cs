﻿using BussinessLayer;
using FullRealProject.Global_Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.TestTypesForms
{
    public partial class frmUpdateTestType : Form
    {

        int _TestTypeID;

        clsTestType _TestType;
        public frmUpdateTestType(int TestTypeID)
        {
            InitializeComponent();
            _TestTypeID = TestTypeID;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void _LoadUI()
        {
            _TestType = clsTestType.Find(_TestTypeID);
            if (_TestType == null)
            {
                MessageBox.Show("TestType was not found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }
            lblTestTypeID.Text = _TestTypeID.ToString();
            tbDescription.Text = _TestType.TestTypeDescription.ToString();
            tbTitle.Text = _TestType.TestTypeTitle.ToString();
            tbFees.Text = _TestType.TestTypeFees.ToString();
        }

        private void _LoadObject(clsTestType TestType)
        {
            TestType.TestTypeTitle = tbTitle.Text;
            TestType.TestTypeFees = Convert.ToDecimal(tbFees.Text);
            TestType.TestTypeDescription = tbDescription.Text;

        }

        private void frmUpdateTestType_Load(object sender, EventArgs e)
        {
            _LoadUI();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!this.ValidateChildren())
            {
                MessageBox.Show("Some fileds are not valide!, put the mouse over the red icon(s) to see the erro", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }           

            _TestType.TestTypeTitle = tbTitle.Text.Trim();
            _TestType.TestTypeFees = Convert.ToDecimal(tbFees.Text);
            _TestType.TestTypeDescription = tbDescription.Text.Trim();

            if (_TestType.UpdateTestType())
            {
                MessageBox.Show("Test Type Updated Successfully:)", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Test Type was NOT Updated", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void tbFees_KeyPress(object sender, KeyPressEventArgs e)
        {
            //bool DotInsertedBefore = tbFees.Text.Contains('.'); #if true this means (.) Inserted Before
            if (e.KeyChar == '.' && tbFees.Text.Contains('.'))
            {
                e.Handled = true;
            }
            else
                e.Handled = !char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.';

        }

        private void tbTitle_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(tbTitle.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(tbTitle, "Title cannot be empty!");
            }
            else
            {
                errorProvider1.SetError(tbTitle, null);
            }
        }

        private void tbDescription_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(tbDescription.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(tbDescription, "Title cannot be empty!");
            }
            else
            {
                errorProvider1.SetError(tbDescription, null);
            }
        }

        private void tbFees_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(tbFees.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(tbFees, "Fees cannot be empty!");
            }
            else
            {
                errorProvider1.SetError(tbFees, null);
            }
            if (!clsValidation.IsNumber(tbFees.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(tbFees, "Invalid Number.");
            }
            else
            {
                errorProvider1.SetError(tbFees, null);
            }
        }
    }
}
