﻿using BussinessLayer;
using FullRealProject.ApplicationTypesForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.TestTypesForms
{
    public partial class frmManageTestsTypes : Form
    {
        private DataTable _dtAllTestTypes;
        public frmManageTestsTypes()
        {
            InitializeComponent();
        }

       
        private void _Refresh()
        {
             _dtAllTestTypes = clsTestType.GetAllTestTypes();
                
              dgvAllTestTypes.DataSource = _dtAllTestTypes;
            
        }

        private void frmManageTestsTypes_Load(object sender, EventArgs e)
        {
            _Refresh();
            if (dgvAllTestTypes.Rows.Count == 0)           
                return;
            dgvAllTestTypes.Columns[0].HeaderText = "ID";
            dgvAllTestTypes.Columns[0].Width = 60;

            dgvAllTestTypes.Columns[1].HeaderText = "Title";
            dgvAllTestTypes.Columns[1].Width = 180;

            dgvAllTestTypes.Columns[2].HeaderText = "Description";
            dgvAllTestTypes.Columns[2].Width = 320;

            dgvAllTestTypes.Columns[3].HeaderText = "Fees";
            dgvAllTestTypes.Columns[3].Width = 60;

        }

        private void editTestTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUpdateTestType frm = new frmUpdateTestType(Convert.ToInt32(dgvAllTestTypes.CurrentRow.Cells[0].Value));
            frm.ShowDialog();
            _Refresh();
        }
    }
}
