﻿using BussinessLayer;
using FullRealProject.International_Licenses;
using FullRealProject.License_Application_Forms;
using FullRealProject.PeopleForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject
{
    public partial class frmTest : Form
    {
        //private int _PersonID = -1;
        //private clsPeople _Person;
        public frmTest()
        {
            InitializeComponent();
        }
        private void _FormLoad()
        {

                

        }






        private void frmTest_Load(object sender, EventArgs e)
        {
            // ctrPersonDetails1.LoadPersonInfo("N1");
            //_RefreshLoad();
            guna2DataGridView1.DataSource = clsPeople.GetAllPeople();
        }
        public static bool CreateFolderIfDoesNotExist(string FolderPath)
        {

            // Check if the folder exists
            if (!Directory.Exists(FolderPath))
            {
                try
                {
                    // If it doesn't exist, create the folder
                    Directory.CreateDirectory(FolderPath);
                    return true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error creating folder: " + ex.Message);
                    return false;
                }
            }

            return true;

        }
        

        
    }
}
