﻿using BussinessLayer;
using System;
using FullRealProject.Global_Classes;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.TestAppointments_Forms
{
    public partial class frmTakeTestVision : Form
    {
        int _TestAppointmentID;
        int _TestTypeID;
        clsTestAppointment _TestAppointment;
        clsTest _Test;
       
        public frmTakeTestVision(int TestTypeID, int TestAppointment)
        {
            InitializeComponent();
            _TestAppointmentID = TestAppointment;
            _TestTypeID = TestTypeID;
        }
        
        private void _LoadPictureAndTitle()
        {
            if (_TestTypeID == 1)
            {

                pictureBox1.Image = Properties.Resources.Vision_512;
                this.Text = "Take Vision Test";
            }
            else if (_TestTypeID == 2)
            {

                pictureBox1.Image = Properties.Resources.Written_Test_512;
                this.Text = "Take Writtent Test";
            }
            else if (_TestTypeID == 3)
            {
                pictureBox1.Image = Properties.Resources.Driving_Test;
                this.Text = "Take Practical Test";
            }
        }
        private void _Load()
        {
            _LoadPictureAndTitle();


            _TestAppointment = clsTestAppointment.Find(_TestAppointmentID);
            _Test = new clsTest();
            if(_TestAppointment == null)
            {
                MessageBox.Show("Couldn't find this Application");
                this.Close();
                return;
            }
            ctrTestAppointmentDetails1.LoadControl(_TestTypeID,_TestAppointment, true);
            clsLocalDrivingLicenseApplication localDrivingLicenseApplication =
                clsLocalDrivingLicenseApplication.Find(_TestAppointment.LDLAppID);
            ctrTestAppointmentDetails1.Trial = localDrivingLicenseApplication.TotalTrialsPerTest(_TestTypeID).ToString();


        }
        private void LoadObj(ref clsTest Test)
        {
            //if(rbPass.Checked)
            //    Test.TestResult = true;
            //else 
            //    Test.TestResult = false;

            Test.TestResult = rbPass.Checked;
            Test.TestAppointmentID = _TestAppointmentID;
            Test.CreatedByUserID = clsGlobal.CurrentUser.UserID;
            Test.Notes = tbNotes.Text.Trim();
        }
        private bool _LockAppointment(ref clsTestAppointment appointment)
        {
            appointment.IsLocked = true;
           
            //appointment.Mode = clsTestAppointment.enMode.Update;

            return appointment.Save();
        }

        private void brnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are you Sure you want to Save ?" +
                "You Cant Change the Result after the Save", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
            {
                return;
            }

            LoadObj(ref _Test);

            //if(!_LockAppointment(ref _TestAppointment))
            //{
            //    MessageBox.Show("Appointment was not locked");
            //    return;
            //}

            //int RTAppID = clsTestAppointment.GetRetakeTestAppIDByTestAppointment(_TestAppointmentID);
            //if(RTAppID != -1)
            //{
            //    clsApplication app = clsApplication.Find(RTAppID);
            //    app.Status = clsApplication.enStatus.Completed;
            //    app.Save();
            //}
            

            if(_Test.AddNewTest())
            {
                if (MessageBox.Show("Test was Saved Successfully!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information) == DialogResult.OK)
                {
                    this.Close();
                }

            }
            else
            {
                MessageBox.Show("Test Was Not Saved ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void frmTakeTestVision_Load(object sender, EventArgs e)
        {
            _Load();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
