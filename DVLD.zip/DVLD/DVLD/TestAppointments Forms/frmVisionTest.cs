﻿using BussinessLayer;
using FullRealProject.PeopleForms;
using FullRealProject.TestAppointments_Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject
{
    public partial class frmVisionTest : Form
    {
        int _LDLAppID;
        int _TestTypeID;
        private DataTable _dtLicenseTestAppointments;

        public frmVisionTest(int TestTypeID, int LDLAppID)
        {
            InitializeComponent();
            _LDLAppID = LDLAppID;
            _TestTypeID = TestTypeID;
        }

        private void _LoadTestTypeImageAndTitle()
        {
            if (_TestTypeID == 1)
            {
                pictureBox1.Image = Properties.Resources.Vision_512;
                lblTitle.Text = "Vision Test Appointments";
            }
            else if (_TestTypeID == 2)
            {
                pictureBox1.Image = Properties.Resources.Written_Test_512;
                lblTitle.Text = "Theoretical Test Appointments";

            }
            else if (_TestTypeID == 3)
            {
                pictureBox1.Image = Properties.Resources.Driving_Test;
                lblTitle.Text = "Practical Test Appointments";
            }

            this.Text = lblTitle.Text;
        }

        private void _Refresh()
        {
            ctrLocalDrivingLicenseAppDetails1.LoadLDLAppInfo(_LDLAppID);
            _dtLicenseTestAppointments = clsTestAppointment.GetAllTestAppointmentsByTestTypeIDAndLDLAppID(_TestTypeID, _LDLAppID);

            dgvAppointments.DataSource = _dtLicenseTestAppointments;
            lblRecordsCount.Text = dgvAppointments.RowCount.ToString();
            

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmVisionTest_Load(object sender, EventArgs e)
        {
            _LoadTestTypeImageAndTitle();
            _Refresh();

            if (dgvAppointments.Rows.Count > 0)
            {
                dgvAppointments.Columns[0].HeaderText = "Appointment ID";

                dgvAppointments.Columns[1].HeaderText = "Appointment Date";

                dgvAppointments.Columns[2].HeaderText = "Paid Fees";

                dgvAppointments.Columns[3].HeaderText = "Is Locked";
            }
        }

        private bool isPassed(int TestAppointmentID)
        {
            //dgvAppointments.Sort(dgvAppointments.Columns[0], ListSortDirection.Descending);
            if (clsTestAppointment.IsPassed(TestAppointmentID))
            {
                
                return true;
            }
            return false;
        }
        private bool IsActiveAppointment()
        {
            dgvAppointments.Sort(dgvAppointments.Columns[0], ListSortDirection.Descending);
            if (Convert.ToBoolean(dgvAppointments.Rows[0].Cells["IsLocked"].Value) == false)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private void btnAddAppointment_Click(object sender, EventArgs e)
        {            
            if (dgvAppointments.RowCount == 0)
            {
                frmAddEditVisionTest frm = new frmAddEditVisionTest(_TestTypeID,-1, _LDLAppID);
                frm.ShowDialog();
                _Refresh();
                return;
            }

            clsLocalDrivingLicenseApplication localDrivingLicenseApplication =  clsLocalDrivingLicenseApplication.Find(_LDLAppID);
            if (localDrivingLicenseApplication.IsThereAnActiveScheduledTest(_TestTypeID))
            {
                MessageBox.Show("Person Already has an Active Appointment for this Test!" 
                    , "Not Allowed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            //if (IsActiveAppointment())
            //{
            //    MessageBox.Show("Person Already has an Active Appointment for this Test!" 
            //        , "Not Allowed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    return;
            //}

            //dgvAppointments.Sort(dgvAppointments.Columns[0], ListSortDirection.Descending);

            clsTest LastTest = localDrivingLicenseApplication.GetLastTestPerTestType(_TestTypeID);

            if (LastTest == null)
            {
                frmAddEditVisionTest frm1 = new frmAddEditVisionTest(_TestTypeID, -1, _LDLAppID);
                frm1.ShowDialog();
                _Refresh();
                return;
            }

            //if person already passed the test s/he cannot retak it.
            if (LastTest.TestResult == true)
            {
                MessageBox.Show("This person already passed this test before, you can only retake faild test", "Not Allowed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                frmAddEditVisionTest frm2 = new frmAddEditVisionTest
                   ( _TestTypeID, -1, LastTest.TestAppointmentInfo.LDLAppID);
                frm2.ShowDialog();
                _Refresh();
            }

               

//            if (isPassed(Convert.ToInt32(dgvAppointments.Rows[0].Cells[0].Value)))
//            {
//                MessageBox.Show(@"The Person Already Passed this Test !
//You Can Only Retake Failed Tests", "Not Allowed", MessageBoxButtons.OK, MessageBoxIcon.Error);
//                return;
//            }
//            else
//            {
//                // Retake Test Form
//                frmAddEditVisionTest frm = new frmAddEditVisionTest(_TestTypeID, -1, _LDLAppID);
//                frm.ShowDialog();
//                _Refresh();
//                return;
//            }
           
            
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int TApp = Convert.ToInt32(dgvAppointments.CurrentRow.Cells[0].Value);
           

            frmAddEditVisionTest frm = new frmAddEditVisionTest(_TestTypeID, TApp, _LDLAppID);
            frm.ShowDialog();
            _Refresh();
        }

        private void takeTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTakeTestVision frm = new frmTakeTestVision(_TestTypeID, Convert.ToInt32(dgvAppointments.CurrentRow.Cells[0].Value));
            frm.ShowDialog();
            _Refresh();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            var row = dgvAppointments.CurrentRow;
            takeTestToolStripMenuItem.Enabled = Convert.ToBoolean(row.Cells[3].Value) == false;
        }
    }
}
