﻿using BussinessLayer;
using System;
using FullRealProject.Global_Classes;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.TestAppointments_Forms
{
    public partial class frmAddEditVisionTest : Form
    {
        int _TestAppointmentID;
        int _LDLAppID;
        int _TestTypeID = 1;
        private clsLocalDrivingLicenseApplication _LocalDrivingLicenseApplication;
        clsTestAppointment _Appointment;
        //int _Trials;
        // bool _RetakeTest;
        public enum enMode { AddNew = 0, Update = 1 }
        enMode Mode;
        public enum enCreationMode { FirstTimeSchedule = 0, RetakeTestSchedule = 1 };
        private enCreationMode _CreationMode = enCreationMode.FirstTimeSchedule;

        public frmAddEditVisionTest(int TestTypeID, int TestAppointmentID, int LDLAppID)
        {
            InitializeComponent();
            _TestAppointmentID = TestAppointmentID;

            if(_TestAppointmentID == -1)
                Mode = enMode.AddNew;
            else
                Mode = enMode.Update;
            _TestTypeID = TestTypeID;
            _LDLAppID = LDLAppID;
            
        }
       

        private void UpdatePictureAndTitle()
        {
            if (_TestTypeID == 1)
            {

                pictureBox1.Image = Properties.Resources.Vision_512;
                this.Text = (Mode == enMode.AddNew ? "Add" : "Update") + "Vision Test";
            }
            else if (_TestTypeID == 2)
            {

                pictureBox1.Image = Properties.Resources.Written_Test_512;
                this.Text = (Mode == enMode.AddNew ? "Add" : "Update") + "Written Test";
            }
            else if (_TestTypeID == 3)
            {

                pictureBox1.Image = Properties.Resources.Driving_Test;
                this.Text = (Mode == enMode.AddNew ? "Add" : "Update") + "Practical Test";
            }
        }

        private void _Load()
        {

            UpdatePictureAndTitle();
            _LocalDrivingLicenseApplication = clsLocalDrivingLicenseApplication.Find(_LDLAppID);
            if (_LocalDrivingLicenseApplication == null)
            {
                MessageBox.Show("Error: No Local Driving License Application with ID = " + _LDLAppID.ToString(),
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnSave.Enabled = false;
                return;
            }


            if (_LocalDrivingLicenseApplication.DoesAttendTestType(_TestTypeID))

                _CreationMode = enCreationMode.RetakeTestSchedule;
            else
                _CreationMode = enCreationMode.FirstTimeSchedule;


            if (_CreationMode == enCreationMode.RetakeTestSchedule)
            {
                lblRAppFees.Text = clsApplicationType.Find((int)clsApplication.enApplicationType.RetakeTest).ApplicationFees.ToString();
                gbRetakeTest.Enabled = true;
                lblTitle.Text = "Schedule Retake Test";
                
                lblRTestAppID.Text = "0";
            }
            else
            {
                gbRetakeTest.Enabled = false;
                lblTitle.Text = "Schedule Test";
                lblRAppFees.Text = "0";
                lblRTestAppID.Text = "N/A";
            }
            this.Text = lblTitle.Text;


            if (Mode == enMode.AddNew)
            {
                _Appointment = new clsTestAppointment();
                ctrTestAppointmentDetails1.LoadObj(_TestTypeID, ref _Appointment, _LDLAppID);
            }
            else
            {
                _Appointment = clsTestAppointment.Find(_TestAppointmentID);
                if (_Appointment == null)
                {
                    MessageBox.Show("Error: No Appointment with ID = " + _TestAppointmentID.ToString(),
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    btnSave.Enabled = false;
                    return ;
                }
                ctrTestAppointmentDetails1.LoadControl(_TestTypeID, _Appointment);
                
                if (_Appointment.RetakeTestApplicationID == -1)
                {
                    lblRAppFees.Text = "0";
                    lblRTestAppID.Text = "N/A";
                }
                else
                {
                    lblRAppFees.Text = _Appointment.RetakeTestAppInfo.PaidFees.ToString();
                    gbRetakeTest.Enabled = true;
                    lblTitle.Text = "Schedule Retake Test";
                    lblRTestAppID.Text = _Appointment.RetakeTestApplicationID.ToString();

                }

            }

            ctrTestAppointmentDetails1.Trial = _LocalDrivingLicenseApplication.TotalTrialsPerTest(_TestTypeID).ToString();

            lblTotalFees.Text =  (clsTestType.Find(_TestTypeID).TestTypeFees + Convert.ToDecimal(lblRAppFees.Text)).ToString();

            if (!_HandleAppointmentLockedConstraint())
                return;
            

        }

        private void frmAddEditVisionTest_Load(object sender, EventArgs e)
        {
            _Load();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private bool _HandleRetakeApplication()
        {
            if (_CreationMode == enCreationMode.RetakeTestSchedule && Mode == enMode.AddNew)
            {
                clsApplication App = new clsApplication();

                App.ApplicantPersonID = _LocalDrivingLicenseApplication.ApplicantPersonID;
                App.ApplicationTypeID = (int)clsApplication.enApplicationType.RetakeTest;
                App.PaidFees = clsApplicationType.Find(App.ApplicationTypeID).ApplicationFees;
                App.CreatedByUserID = clsGlobal.CurrentUser.UserID;
                App.ApplicationDate = DateTime.Now;
                App.Status = clsApplication.enStatus.Completed;
                App.LastStatusDate = DateTime.Now;

                if (!App.Save())
                {
                    _Appointment.RetakeTestApplicationID = -1;
                    MessageBox.Show("Retake Application Was not Saved", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                _Appointment.RetakeTestApplicationID = App.ApplicationID;              
            }
            return true;
        }

        private bool _HandleAppointmentLockedConstraint()
        {
            //if appointment is locked that means the person already sat for this test
            //we cannot update locked appointment
            if (_Appointment.IsLocked)
            {
                lblMessage.Visible = true;
                lblMessage.Text = "Person already sat for the test, appointment loacked.";
                ctrTestAppointmentDetails1.Enabled = false;
                btnSave.Enabled = false;
                return false;

            }
            else
                lblMessage.Visible = false;

            return true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            if (!_HandleRetakeApplication())
                return;

            ctrTestAppointmentDetails1.LoadObj(_TestTypeID, ref _Appointment, _LDLAppID);

            
           
            if(_Appointment.Save())
            {
                if(MessageBox.Show("Appointment Saved Successfully", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information) == DialogResult.OK)
                    this.Close();
            }
            else
            {
                MessageBox.Show("Appointment Was Not Saved", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }

        private void btnClose_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
