﻿using BussinessLayer;
using FullRealProject.Driving_License_Forms;
using FullRealProject.PeopleForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.Drivers_Forms
{
    public partial class frmManageDrivers : Form
    {

        private DataTable _dtAllDrivers;
        public frmManageDrivers()
        {
            InitializeComponent();
        }

        private void _Refresh()
        {
            
            _dtAllDrivers = clsDriver.GetAllDrivers();
            
             dgvAllDrivers.DataSource = _dtAllDrivers;
             lblRecordsCount.Text = (dgvAllDrivers.RowCount).ToString();
            
           
        }
        private void frmManageDrivers_Load(object sender, EventArgs e)
        {
            _Refresh();
            cbFilter.SelectedIndex = 0;
            tbFilter.Visible = false;
            if (dgvAllDrivers.Rows.Count > 0)
            {
                dgvAllDrivers.Columns[0].HeaderText = "Driver ID";

                dgvAllDrivers.Columns[1].HeaderText = "Person ID";

                dgvAllDrivers.Columns[2].HeaderText = "National No.";

                dgvAllDrivers.Columns[3].HeaderText = "Full Name";

                dgvAllDrivers.Columns[4].HeaderText = "Date";

                dgvAllDrivers.Columns[5].HeaderText = "Active Licenses";

            }
            //Image img = new Bitmap(Properties.Resources.Close_32, new Size(24, 24));
            //btnClose.Image = img;
            //btnClose.ImageAlign = ContentAlignment.MiddleLeft;

        }


        private void cbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            tbFilter.Visible = cbFilter.SelectedIndex != 0;

            tbFilter.Text = "";
            tbFilter.Focus();
        }

        

        private void tbFilter_TextChanged(object sender, EventArgs e)
        {
            string FilterColumn = "";
            //Map Selected Filter to real Column name 
            switch (cbFilter.Text)
            {
                case "Driver ID":
                    FilterColumn = "DriverID";
                    break;

                case "Person ID":
                    FilterColumn = "PersonID";
                    break;

                case "National No.":
                    FilterColumn = "NationalNo";
                    break;


                case "Full Name":
                    FilterColumn = "FullName";
                    break;

                default:
                    FilterColumn = "None";
                    break;

            }

            //Reset the filters in case nothing selected or filter value conains nothing.
            if (tbFilter.Text.Trim() == "" || FilterColumn == "None")
            {
                _dtAllDrivers.DefaultView.RowFilter = "";
                lblRecordsCount.Text = dgvAllDrivers.Rows.Count.ToString();
                return;
            }


            if (FilterColumn != "FullName" && FilterColumn != "NationalNo")
                //in this case we deal with numbers not string.
                _dtAllDrivers.DefaultView.RowFilter = string.Format("[{0}] = {1}", FilterColumn, tbFilter.Text.Trim());
            else
                _dtAllDrivers.DefaultView.RowFilter = string.Format("[{0}] LIKE '{1}%'", FilterColumn, tbFilter.Text.Trim());

            lblRecordsCount.Text = dgvAllDrivers.Rows.Count.ToString();

        }

        private void tbFilter_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (cbFilter.Text == "Person ID" || cbFilter.Text == "Driver ID")
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                {
                    e.Handled = true; // block the input
                }
            }
        }

        private void showDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int PersonID = (int)dgvAllDrivers.CurrentRow.Cells[1].Value;
            frmShowDetails frm = new frmShowDetails(PersonID);
            frm.ShowDialog();
            //refresh
            _Refresh();
        }

        

        private void showPersonLicenseHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string NationalNo = dgvAllDrivers.CurrentRow.Cells[2].Value.ToString();


            frmShowPersonLicenseHistory frm = new frmShowPersonLicenseHistory(NationalNo);
            frm.ShowDialog();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
