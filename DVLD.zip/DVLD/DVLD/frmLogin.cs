﻿using BussinessLayer;
using FullRealProject.Global_Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace FullRealProject
{
    public partial class frmLogin : Form
    {
        clsUser _User;
        public frmLogin()
        {
            InitializeComponent();
        }

        private Image ResizeImage(Image img, Size size)
        {
            return new Bitmap(img, size);
        }

        private void Build()
        {
           // btnClose.FlatAppearance.BorderSize = 0;
            btnLogin.Image = ResizeImage(Properties.Resources.login, new Size(18, 18));

        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            Build();
            string UserName = "", Password = "";

            if (clsGlobal.GetStoredCredential(ref UserName, ref Password))
            {
                tbUserName.Text = UserName;
                tbPassword.Text = Password;
                chkRememberMe.Checked = true;
            }
            else
            {
                chkRememberMe.Checked = false;
            }

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.AutoValidate = AutoValidate.Disable;
            this.Close();
        }


        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (!this.ValidateChildren())
            {
                //MessageBox.Show("Some fileds are not valide!, put the mouse over the red icon(s) to see the error", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            _User = clsUser.Find(tbUserName.Text.Trim());


            

            if(_User == null)
            {
                MessageBox.Show("This User does not exist!", "Error",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbUserName.Focus();
                return;
            }

            if (tbPassword.Text.Trim() != _User.Password)
            {
                MessageBox.Show("Password is incorrect!", "Error",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
               return;
            }

            if (!_User.isActive )
            {
                MessageBox.Show("Your Account is Not Active", "Error",
                  MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (chkRememberMe.Checked)
            {
                //store username and password
                clsGlobal.RememberUsernameAndPassword(tbUserName.Text.Trim(), tbPassword.Text.Trim());

            }
            else
            {
                //store empty username and password
                clsGlobal.RememberUsernameAndPassword("", "");

            }
            clsGlobal.CurrentUser = _User;
            Form frm = new frmMainScreen();
            this.Hide();
            frm.ShowDialog();
            this.Show();
                      

        }

        
        private void Validating(object sender, CancelEventArgs e)
        {
            TextBox temp = ((TextBox)sender);
            if (string.IsNullOrEmpty(temp.Text.Trim()))
            {
                e.Cancel = true;
                //((TextBox)sender).Focus();
                errorProvider1.SetError(temp, "This Feild Cannot be empty!");
            }
            else
            {
               // e.Cancel = false;
                errorProvider1.SetError(temp, null);
            }
        }

        
    }
}
