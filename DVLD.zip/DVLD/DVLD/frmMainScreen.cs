﻿using FullRealProject.ApplicationTypesForms;
using FullRealProject.Drivers_Forms;
using FullRealProject.Driving_License_Forms;
using FullRealProject.Global_Classes;
using FullRealProject.International_Licenses;
using FullRealProject.License_Application_Forms;
using FullRealProject.LocalLicense_Application_Forms;
using FullRealProject.PeopleForms;
using FullRealProject.TestTypesForms;
using FullRealProject.UserForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject
{
    public partial class frmMainScreen : Form
    {
        public frmMainScreen()
        {
            InitializeComponent();
        }
        private Image ResizeImage(Image img, Size size)
        {
            return new Bitmap(img, size);
        }

        private void BuildMenu()
        {          
            menuStrip1.ImageScalingSize = new Size(48, 48);

            peopleToolStripMenuItem.Image = ResizeImage(Properties.Resources.people, new Size(48, 48));
            applicationsToolStripMenuItem.Image = ResizeImage(Properties.Resources.Application, new Size(48, 48));
            driversToolStripMenuItem.Image = ResizeImage(Properties.Resources.drivers, new Size(48, 48));
            usersToolStripMenuItem.Image = ResizeImage(Properties.Resources.multiple_users_silhouette, new Size(48, 48));
            accountSettingsToolStripMenuItem.Image = ResizeImage(Properties.Resources.settings, new Size(48, 48));

            logOutToolStripMenuItem.ImageScaling = ToolStripItemImageScaling.None;
            logOutToolStripMenuItem.Image = ResizeImage(Properties.Resources.Sign_Out_32, new Size(32, 32));
            currentUserInfoToolStripMenuItem.ImageScaling = ToolStripItemImageScaling.None;
            currentUserInfoToolStripMenuItem.Image = ResizeImage(Properties.Resources.PersonDetails_32, new Size(32,32));
            changePasswordToolStripMenuItem.ImageScaling = ToolStripItemImageScaling.None;
            changePasswordToolStripMenuItem.Image = ResizeImage(Properties.Resources.Password_32, new Size(32, 32));

            manageApplicationTypesToolStripMenuItem.Image = ResizeImage(Properties.Resources.ApplicationType, new Size(48, 48));
            drivingLicenseServicesToolStripMenuItem.Image = ResizeImage(Properties.Resources.Driver_License_48, new Size(48, 48));
            manageApplicationsToolStripMenuItem.Image = ResizeImage(Properties.Resources.Applications, new Size(48, 48));
            detainLicensesToolStripMenuItem.Image = ResizeImage(Properties.Resources.Detain_32, new Size(48, 48));
            detainLicensesToolStripMenuItem.Image = ResizeImage(Properties.Resources.Detain_32, new Size(48, 48));
            manageTestTypesToolStripMenuItem.Image = ResizeImage(Properties.Resources.TestType_32, new Size(48, 48));

            // toolTip1.SetToolTip(accountSettingsToolStripMenuItem, "Logged in as: " + clsGlobal.CurrentUser.UserName);
            accountSettingsToolStripMenuItem.ToolTipText = "Logged in as : " + clsGlobal.CurrentUser.UserName;

        }
        private void frmMainScreen_Load(object sender, EventArgs e)
        {
            BuildMenu();
        }

        
        private void peopleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frm = new frmManagePeople();
            frm.ShowDialog();
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clsGlobal.CurrentUser = null;
            this.Close();
        }

        private void usersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frm = new frmManageUsers();
            frm.ShowDialog();
        }

        private void currentUserInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUserDetails frm = new frmUserDetails(clsGlobal.CurrentUser.UserID);
            frm.ShowDialog();
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmChangePassword frm = new frmChangePassword(clsGlobal.CurrentUser.UserID);
            frm.ShowDialog();
        }

        private void manageApplicationTypesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmManageApplicationTypes frm = new frmManageApplicationTypes();
            frm.ShowDialog();
        }

        private void manageTestTypesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmManageTestsTypes frm = new frmManageTestsTypes();
            frm.ShowDialog();
        }

        private void localLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmNewLocalLicenseApplication frm = new frmNewLocalLicenseApplication(-1);
            frm.ShowDialog();
        }


        private void localDrivingLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmManageLocalDrivingLicenseApplications frm = new frmManageLocalDrivingLicenseApplications();
            frm.ShowDialog();
        }

        private void driversToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmManageDrivers frm = new frmManageDrivers();
            frm.ShowDialog();
        }

        private void internationalLicneseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            frmInternationalLicenseApplication frm = new frmInternationalLicenseApplication();
            frm.ShowDialog();
        }

        private void internationalLicenseApplicationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmInternationalLicenseApplications frm = new frmInternationalLicenseApplications();
            frm.ShowDialog();
        }

        private void renewDrivingLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmRenewLicense frm = new frmRenewLicense();
            frm.ShowDialog();
        }

        private void replacementForLostOrDamagedLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReplacmentDrivingLicense frm = new frmReplacmentDrivingLicense();
            frm.ShowDialog();
        }

        private void detainLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDetainLicense frm = new frmDetainLicense();
            frm.ShowDialog();
        }

        private void releaseDetainedLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReleaseDetainedLicense frm = new frmReleaseDetainedLicense();
            frm.ShowDialog();
        }

        private void manageDetainedLicensesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clsListDetainedLicenses frm = new clsListDetainedLicenses();
            frm.ShowDialog();
        }

        private void releaseDetainedDrivingLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReleaseDetainedLicense frm = new frmReleaseDetainedLicense();
            frm.ShowDialog();
        }

        private void retakeTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmManageLocalDrivingLicenseApplications frm = new frmManageLocalDrivingLicenseApplications();
            frm.ShowDialog();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void accountSettingsToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {

        }
    }
}
