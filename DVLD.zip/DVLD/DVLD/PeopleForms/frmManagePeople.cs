﻿using BussinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FullRealProject.PeopleForms
{
    public partial class frmManagePeople : Form
    {
        private static DataTable _dtAllPeople = clsPeople.GetAllPeople();

        public frmManagePeople()
        {
            InitializeComponent();
        }

        private void _RefreshPeopleList()
        {

            //cbFilter.SelectedIndex = 0;
            //tbFilter.Visible = false;
            _dtAllPeople = clsPeople.GetAllPeople();
           
            
            dgvAllPeople.DataSource = _dtAllPeople;
            lblRecordsCount.Text = (dgvAllPeople.RowCount).ToString();
            
            
        }
        private void frmManagePeople_Load(object sender, EventArgs e)
        {
            //tbFilter.Visible = false;
            //_RefreshPeopleList();
            cbFilter.SelectedIndex = 0;
            dgvAllPeople.DataSource = _dtAllPeople;
            lblRecordsCount.Text = (dgvAllPeople.RowCount).ToString();

            if (dgvAllPeople.Rows.Count > 0)
            {

                dgvAllPeople.Columns[0].HeaderText = "Person ID";
                dgvAllPeople.Columns[0].Width = 50;

                dgvAllPeople.Columns[1].HeaderText = "National No.";
                dgvAllPeople.Columns[1].Width = 50;


                dgvAllPeople.Columns[2].HeaderText = "First Name";
                dgvAllPeople.Columns[2].Width = 60;

                dgvAllPeople.Columns[3].HeaderText = "Second Name";
                dgvAllPeople.Columns[3].Width = 60;


                dgvAllPeople.Columns[4].HeaderText = "Third Name";
                dgvAllPeople.Columns[4].Width = 60;

                dgvAllPeople.Columns[5].HeaderText = "Last Name";
                dgvAllPeople.Columns[5].Width = 80;

                dgvAllPeople.Columns[6].HeaderText = "Date Of Birth";
                dgvAllPeople.Columns[6].Width = 100;

                dgvAllPeople.Columns[7].HeaderText = "Gender";
                dgvAllPeople.Columns[7].Width = 60;

                dgvAllPeople.Columns[8].HeaderText = "Phone";
                dgvAllPeople.Columns[8].Width = 80;


                dgvAllPeople.Columns[9].HeaderText = "Email";
                dgvAllPeople.Columns[9].Width = 120;


                dgvAllPeople.Columns[10].HeaderText = "Nationality";
                dgvAllPeople.Columns[10].Width = 100;
            }
        }



        private void btnAddPerson_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("Button Clicked");
            frmAddEditPerson frm = new frmAddEditPerson(-1);
            frm.ShowDialog();
            _RefreshPeopleList();
        }

       
        private void cbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            tbFilter.Visible = (cbFilter.Text != "None");
           
            if (tbFilter.Visible)
            {
                tbFilter.Text = "";
                tbFilter.Focus();
            }
        }

        private void tbFilter_TextChanged(object sender, EventArgs e)
        {
            string FilterColumn = "";
            //Map Selected Filter to real Column name 
            switch (cbFilter.Text)
            {
                case "Person ID":
                    FilterColumn = "PersonID";
                    break;

                case "National No.":
                    FilterColumn = "NationalNo";
                    break;

                case "First Name":
                    FilterColumn = "FirstName";
                    break;

                case "Second Name":
                    FilterColumn = "SecondName";
                    break;

                case "Third Name":
                    FilterColumn = "ThirdName";
                    break;

                case "Last Name":
                    FilterColumn = "LastName";
                    break;

                case "Nationality":
                    FilterColumn = "CountryName";
                    break;

                case "Gender":
                    FilterColumn = "Gender";
                    break;

                case "Phone":
                    FilterColumn = "Phone";
                    break;

                case "Email":
                    FilterColumn = "Email";
                    break;

                default:
                    FilterColumn = "None";
                    break;

            }

            if (tbFilter.Text.Trim() == "" || cbFilter.Text == "None")
            {
                _dtAllPeople.DefaultView.RowFilter = "";
                lblRecordsCount.Text = dgvAllPeople.Rows.Count.ToString();
                return;
            }

            if (FilterColumn == "PersonID")
            
                _dtAllPeople.DefaultView.RowFilter = string.Format($"[{FilterColumn}] = {tbFilter.Text.Trim()}");           
            else
            
                _dtAllPeople.DefaultView.RowFilter = string.Format($"[{FilterColumn}] LIKE '{tbFilter.Text.Trim()}%'");

            lblRecordsCount.Text = dgvAllPeople.Rows.Count.ToString();

        }


        private void showDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmShowDetails frm = new frmShowDetails(Convert.ToInt32(dgvAllPeople.CurrentRow.Cells[0].Value));
            frm.ShowDialog();
            _RefreshPeopleList();
        }

        private void addNewPersonToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAddEditPerson frm = new frmAddEditPerson(-1);
            frm.ShowDialog();
            _RefreshPeopleList();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAddEditPerson frm = new frmAddEditPerson(Convert.ToInt32(dgvAllPeople.CurrentRow.Cells[0].Value));
            frm.ShowDialog();
            _RefreshPeopleList();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if(clsPeople.DeletePerson(Convert.ToInt32(dgvAllPeople.CurrentRow.Cells[0].Value)))
            {
                MessageBox.Show("Person was Deleted Successfully :)", "Information", MessageBoxButtons.OKCancel
                    , MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                _RefreshPeopleList();
            }
            else
            {
                MessageBox.Show("Person was Not Deleted  :(", "Error", MessageBoxButtons.OKCancel
                   , MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }



        private void sendEmailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This Feature is NOT Implemented Yet!", "Coming Soon", MessageBoxButtons.OKCancel
                 , MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
        }

        private void phoneCallToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This Feature is NOT Implemented Yet!", "Coming Soon", MessageBoxButtons.OKCancel
                 , MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
        }

        private void tbFilter_Validating(object sender, CancelEventArgs e)
        {
            
        }

        private void tbFilter_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (cbFilter.Text == "Person ID" || cbFilter.Text == "Phone")
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                {
                    e.Handled = true; // block the input
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void sendEmailToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
