﻿using BussinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using FullRealProject.UserForms;
using FullRealProject.Global_Classes;

namespace FullRealProject.PeopleForms
{
    public partial class frmAddEditPerson : Form
    {

        public enum enMode { AddNew = 0, Update = 1 };
        public enMode Mode;


        private int _PersonID = -1;
        public clsPeople _Person;

        public  delegate void DataBackEventHandler(object sender, int PersonID);

        public event DataBackEventHandler DataBack;
        
        public frmAddEditPerson(int PersonID)
        {
            InitializeComponent();
            _PersonID = PersonID;
            if(_PersonID == -1)
                Mode = enMode.AddNew;
            else
                Mode = enMode.Update;
        }

        private void _LoadInfo()
        {

            if(Mode == enMode.AddNew)
            {
                lblAddEdit.Text = "Add New Person";
                this.Text = lblAddEdit.Text;
                _Person = new clsPeople();

                return;
            }


            _Person =  clsPeople.Find(_PersonID);

            if (_Person == null)
            {
                MessageBox.Show("No Person with ID = " + _PersonID, "Person Not Found", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.Close();
                return;
            }
            lblAddEdit.Text = "Update Person";
                lblPersonID.Text = _PersonID.ToString();
                ctrAddEditPerson1.LoadControl( _Person);
            this.Text = lblAddEdit.Text;

        }

        private void frmAddEditPerson_Load(object sender, EventArgs e)
        {
            _LoadInfo();
        }
        private bool _HandlePersonImage()
        {
            if (_Person.ImagePath != ctrAddEditPerson1.pictureBox.ImageLocation)
            {
                if (_Person.ImagePath != "")
                {
                    try
                    {
                        File.Delete(_Person.ImagePath);
                    }
                    catch (Exception ex) 
                    {
                        MessageBox.Show("Error: " + ex.Message);
                        return false;
                    }
                }

                if (ctrAddEditPerson1.pictureBox.ImageLocation != null)
                {
                    string sourceFile = ctrAddEditPerson1.pictureBox.ImageLocation.ToString();
                    if (clsUtil.CopyImageToProjectImagesFolder(ref sourceFile))
                    {
                        ctrAddEditPerson1.pictureBox.ImageLocation = sourceFile;
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("Error Copying the Image ");
                        return false;
                    }
                }

            }
            return true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {            

            if (!this.ValidateChildren())
            {
                //Here we dont continue becuase the form is not valid
                MessageBox.Show("Some fileds are not valide!, put the mouse over the red icon(s) to see the error", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            bool isValid = true;

            if (ctrAddEditPerson1.NationalNo.Text.Trim() !=  _Person.NationalNo && clsPeople.IsExist(ctrAddEditPerson1.NationalNo.Text.Trim()))
            {
                errorProvider1.SetError(ctrAddEditPerson1.NationalNo, "National Number is used for another person!");
                isValid = false;
            }
            else
            {
                errorProvider1.SetError(ctrAddEditPerson1.NationalNo, "");
            }

            if (!isValid)
            {
                //MessageBox.Show("National Number is used for another person!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
               
            if (! _HandlePersonImage())
            {
                MessageBox.Show("Error Handling the Image");
                return;
            }


            ctrAddEditPerson1._LoadObject(_Person);        


            if (_Person.Save())
            {
                MessageBox.Show("Person Saved Successfully ", "Information", MessageBoxButtons.OK,
                    MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                Mode = enMode.Update;
                lblAddEdit.Text = "Update Person";
                lblPersonID.Text = _Person.PersonID.ToString();

                DataBack?.Invoke(this, _Person.PersonID);
            }
            else
            {
                MessageBox.Show("Person Was NOT Saved", "Error", MessageBoxButtons.OK,
                   MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            
            this.Close(); 
        }


    }
}
