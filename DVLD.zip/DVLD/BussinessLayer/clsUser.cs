﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BussinessLayer
{
    public class clsUser
    {
        public enum enMode { AddNew = 0, Update = 1 }
        public enMode Mode = enMode.AddNew;

        
        public int UserID { get; set; }
        public int PersonID { get; set; }
        public clsPeople PersonInfo;
        public string UserName { get; set; }
        public string Password { get; set; }
        public bool isActive { get; set; }
        

        public clsUser()
        {
            UserID = -1;
            UserName = "";
            Password = "";
            isActive = true;          
            Mode = enMode.AddNew;

        }


        private clsUser(int UserID, int PersonID, string UserName, string Password,
            bool isActive)
        {
            this.UserID = UserID;
            this.PersonID = PersonID;
            this.PersonInfo = clsPeople.Find(PersonID);
            this.UserName = UserName;
            this.Password = Password;
            this.isActive = isActive;
           
            Mode = enMode.Update;
        }

        public static clsUser Find(int UserID)
        {
            int PersonID = -1;
            string UserName = "", Password = "";
            bool isActive = false;

            if (clsUserDataAccess.GetInfoByUserID(UserID, ref PersonID, ref UserName,
                ref Password, ref isActive))
            {
                return new clsUser(UserID, PersonID, UserName, Password, isActive);
            }
            else
            {
                return null;
            }

        }

        public static clsUser Find(string UserName)
        {
            int PersonID = -1,  UserID = -1;
            string Password = "";
            bool isActive = false;

            if (clsUserDataAccess.GetInfoByUserName(ref UserID, ref PersonID,  UserName,
                ref Password, ref isActive))
            {
                return new clsUser(UserID, PersonID, UserName, Password, isActive);
            }
            else
            {
                return null;
            }

        }

        public static clsUser FindUserByPersonID(int PersonID)
        {
            int UserID = -1;
            string UserName = "", Password = "";
            bool isActive = false;

            if (clsUserDataAccess.GetInfoByPersonID(ref UserID, PersonID, ref UserName,
                ref Password, ref isActive))
            {
                return new clsUser(UserID, PersonID, UserName, Password, isActive);
            }
            else
            {
                return null;
            }

        }

        public static DataTable GetAllUsers()
        {
            return clsUserDataAccess.GetAllUsers();
        }

        private bool _AddNewUser()
        {
            this.UserID = clsUserDataAccess.AddNewUser(this.PersonID, this.UserName,
                this.Password, this.isActive);
            return (this.UserID != -1);
        }

        private bool _UpdateUser()
        {
            return clsUserDataAccess.UpdateUser(this.UserID,  this.UserName,
                this.Password, this.isActive);
        }

        public static bool DeleteUser(int UserID)
        {
            return clsUserDataAccess.DeleteUser(UserID);
        }

        public bool Save()
        {
            switch (Mode)
            {
                case enMode.AddNew:
                    if (_AddNewUser())
                    {
                        Mode = enMode.Update;
                        return true;
                    }
                    else
                        return false;
                case enMode.Update:
                    return _UpdateUser();
            }
            return false;
        }


        public static bool IsExist(int UserID)
        {
            return clsUserDataAccess.IsExist(UserID);
        }
        public static bool IsExist(string UserName)
        {
            return clsUserDataAccess.IsExist(UserName);
        }

        public static bool IsPersonUser(int personID)
        {
            return clsUserDataAccess.IsPersonUser(personID);
        }

        public static bool isMatch(string UserName,  string Password)
        {
            clsUser user = clsUser.Find(UserName);
            if(user == null)
                return false;

            if(string.IsNullOrEmpty(UserName) || string.IsNullOrEmpty(Password))
                return false;

            return user.Password == Password;
            
        }
    }
}
