﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DataAccessLayer;

namespace BussinessLayer
{
    public class clsDriver
    {
        //public enum enMode { AddNew = 0, Update = 1 };
        //public enMode Mode = enMode.AddNew;

        public int DriverID {  get; set; }
        public int PersonID { get; set; }
        public int CreatedByUserID { get; set; }
        public DateTime CreatedDate { get; set; }
        public clsPeople PersonInfo;

        public clsDriver()
        {
            this.DriverID = -1;
            this.PersonID = -1;
            this.CreatedByUserID = -1;
            this.CreatedDate = DateTime.Now;

            //Mode = enMode.AddNew;
        }

        clsDriver(int driverID, int personID, int createdByUserID, DateTime createdDate)
        {
            
            this.DriverID = driverID;
            this.PersonID = personID;
            this.CreatedByUserID = createdByUserID;
            this.CreatedDate = createdDate;
            PersonInfo = clsPeople.Find(PersonID);

            //Mode = enMode.Update;
        }

        public static clsDriver Find(int DriverID)
        {
            int PersonID = -1, CreatedByUserID = -1;
            DateTime CreatedDate = DateTime.MinValue;
            

            if (clsDriverDataAccess.GetInfoByDriverID(DriverID, ref PersonID,  ref CreatedByUserID, 
                ref CreatedDate))
            {
                return new clsDriver(DriverID,  PersonID,  CreatedByUserID,
                 CreatedDate);
            }
            else
            {
                return null;
            }

        }

        public static clsDriver FindByPersonID(int PersonID)
        {
            int DriverID = -1, CreatedByUserID = -1;
            DateTime CreatedDate = DateTime.MinValue;


            if (clsDriverDataAccess.GetInfoByPersonID(ref DriverID,  PersonID, ref CreatedByUserID,
                ref CreatedDate))
            {
                return new clsDriver(DriverID, PersonID, CreatedByUserID,
                 CreatedDate);
            }
            else
            {
                return null;
            }

        }

        public static DataTable GetAllDrivers()
        {
            return clsDriverDataAccess.GetAllDrivers();
        }

        public bool AddNewDriver()
        {
            this.DriverID = clsDriverDataAccess.AddNewDriver(this.PersonID, 
                this.CreatedByUserID, this.CreatedDate);
            return (this.DriverID != -1);
        }

        public static int GetDriverIDByPersonID(int PersonID)
        {
            return clsDriverDataAccess.GetDriverIDByPersonID(PersonID);
        }

        public static DataTable GetLicenses(int DriverID)
        {
            return clsLicense.GetDriverLicenses(DriverID);
        }

        public static DataTable GetInternationalLicenses(int DriverID)
        {
            return clsInternationalLicense.GetDriverInternationalLicenses(DriverID);
        }

    }
}
