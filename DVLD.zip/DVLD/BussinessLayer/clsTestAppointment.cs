﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DataAccessLayer;

namespace BussinessLayer
{
    public class clsTestAppointment
    {
        public enum enMode { AddNew = 0, Update = 1 }
        public enMode Mode = enMode.AddNew;

        public int TestAppointmentID {  get; set; }
        public int TestTypeID { get; set; }
        public int LDLAppID { get; set; }
        public DateTime AppointmentDate { get; set; }
        public decimal PaidFees { get; set; }
        public int CreatedByUserID { get; set; }
        public bool IsLocked { get; set; }
        public int RetakeTestApplicationID {  get; set; }
        public clsApplication RetakeTestAppInfo { set; get; }

        public  int GetTestID
        {
            get
            {
                return _GetTestID();
            }
        }

        public clsTestAppointment()
        {
            TestAppointmentID = -1;
            TestTypeID = -1;
            LDLAppID = -1;
            AppointmentDate = DateTime.Now;
            PaidFees = -1;
            CreatedByUserID = -1;
            //IsLocked = false;
            RetakeTestApplicationID = -1;

            Mode  = enMode.AddNew;
        }

        private clsTestAppointment(int testAppointmentID, int TestTypeID, int LDLAppID,
            DateTime AppointmentDate, decimal PaidFees, int CreatedByUserID, bool IsLocked, int RTAppID)
        {
            this.TestAppointmentID = testAppointmentID;
            this.TestTypeID = TestTypeID;
            this.LDLAppID = LDLAppID;
            this.AppointmentDate = AppointmentDate;
            this.PaidFees = PaidFees;
            this.CreatedByUserID = CreatedByUserID;
            this.IsLocked = IsLocked;
            this.RetakeTestApplicationID= RTAppID;
            this.RetakeTestAppInfo = clsApplication.Find(RTAppID);

            Mode = enMode.Update;
        }


        public static clsTestAppointment Find(int TestAppointmentID)
        {
            int TestTypeID = -1, LDLAppID = -1, CreatedByUserID = -1, ReTakeTestApplicationID = -1;
            DateTime AppointmentDate = DateTime.Now;
            decimal PaidFees = -1;
            bool IsLocked = false;

            if (clsTestAppointmentDataAccess.GetInfoByTestAppointmentID( TestAppointmentID, ref  TestTypeID, ref  LDLAppID,
            ref  AppointmentDate, ref  PaidFees, ref  CreatedByUserID, ref  IsLocked, ref ReTakeTestApplicationID))
            {
                return new clsTestAppointment(TestAppointmentID, TestTypeID, LDLAppID, AppointmentDate, PaidFees, CreatedByUserID
                    , IsLocked, ReTakeTestApplicationID);
            }
            else
            {
                return null;
            }

        }

        public static DataTable GetAllTestAppointmentsByTestTypeIDAndLDLAppID(int TestTypeID, int LDLAppID)
        {
            return clsTestAppointmentDataAccess.GetAllTestAppointmentsByTestTypeIDAndLDLAppID(TestTypeID, LDLAppID);
        }
        public static clsTestAppointment GetLastTestAppointment(int LocalDrivingLicenseApplicationID, int TestTypeID)
        {
            int TestAppointmentID = -1;
            DateTime AppointmentDate = DateTime.Now; decimal PaidFees = 0;
            int CreatedByUserID = -1; bool IsLocked = false; int RetakeTestApplicationID = -1;

            if (clsTestAppointmentDataAccess.GetLastTestAppointment(LocalDrivingLicenseApplicationID, TestTypeID,
                ref TestAppointmentID, ref AppointmentDate, ref PaidFees, ref CreatedByUserID, ref IsLocked, ref RetakeTestApplicationID))

                return new clsTestAppointment(TestAppointmentID, TestTypeID, LocalDrivingLicenseApplicationID,
             AppointmentDate, PaidFees, CreatedByUserID, IsLocked, RetakeTestApplicationID);
            else
                return null;

        }

        private bool _AddNewTestAppointment()
        {
            this.TestAppointmentID = clsTestAppointmentDataAccess.AddNewTestAppointment(this.TestTypeID
                , this.LDLAppID, this.AppointmentDate, this.PaidFees, this.CreatedByUserID,
                this.IsLocked, this.RetakeTestApplicationID);
            return (this.TestAppointmentID != -1);
        }

        private bool _UpdateTestAppointment()
        {
            return clsTestAppointmentDataAccess.UpdateTestAppointment(this.TestAppointmentID, 
                this.TestTypeID, this.LDLAppID, this.AppointmentDate, this.PaidFees, this.CreatedByUserID, 
                this.IsLocked ,this.RetakeTestApplicationID);
        }

        public static bool DeleteTestAppointment(int TestAppointmentID)
        {
            return clsTestAppointmentDataAccess.DeleteTestAppointment(TestAppointmentID);
        }

        public bool Save()
        {
            switch (Mode)
            {
                case enMode.AddNew:
                    if (_AddNewTestAppointment())
                    {
                        Mode = enMode.Update;
                        return true;
                    }
                    else
                        return false;
                case enMode.Update:
                    return _UpdateTestAppointment();
            }
            return false;
        }

        public static bool IsPassed(int TestAppointmentID)
        {
            return clsTestAppointmentDataAccess.IsPassed(TestAppointmentID);
        }


        public static int GetRetakeTestAppIDByTestAppointment(int TestAppointmentID)
        {
            return clsTestAppointmentDataAccess.GetRetakeTestAppIDByTestAppointment(TestAppointmentID) ;
        }

        private int _GetTestID()
        {
            return clsTestAppointmentDataAccess.GetTestID(TestAppointmentID);
        }

    }
}
