﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace BussinessLayer
{
    public class clsCountry
    {
        public int CountryID { get; set; }
        public string CountryName { get; set; }

        clsCountry()
        {
            CountryID = -1;
            CountryName = "";
        }
        clsCountry(int countryID, string countryName)
        {
            this.CountryID = countryID;
            this.CountryName = countryName;
        }

        public static clsCountry Find(int CountryID)
        {
            string CountryName = clsCountryDataAccess.GetCountryNameByID(CountryID);
            if (CountryName != "")
            {
                return new clsCountry(CountryID, CountryName);
            }
            else
                return null;
        }

        public static clsCountry Find(string CountryName)
        {
            int CountryID = clsCountryDataAccess.GetCountryIDByName(CountryName);
            if (CountryID != -1)
            {
                return new clsCountry(CountryID, CountryName);
            }
            else
                return null;
        }
        public static DataTable GetAllCountries()
        {
            return clsCountryDataAccess.GetAllCountries();
        }
    }
}
