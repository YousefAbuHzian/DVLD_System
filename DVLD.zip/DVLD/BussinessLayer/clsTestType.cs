﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;
using System.Data;

namespace BussinessLayer
{
    public class clsTestType
    {

        public int TestTypeID { get; set; }

        public string TestTypeTitle { get; set; }
        public string TestTypeDescription { get; set; }

        public decimal TestTypeFees { get; set; }

        clsTestType(int TestTypeID, string TestTypeTitle, string TestTypeDescription, decimal TestTypeFees)
        {
            this.TestTypeID = TestTypeID;
            this.TestTypeTitle = TestTypeTitle;
            this.TestTypeFees = TestTypeFees;
            this.TestTypeDescription = TestTypeDescription;
        }

        public static DataTable GetAllTestTypes()
        {
            return clsTestTypeDataAccess.GetAllTestTypes();
        }

        public bool UpdateTestType()
        {
            return clsTestTypeDataAccess.UpdateTestType(this.TestTypeID, this.TestTypeTitle,
               this.TestTypeDescription , this.TestTypeFees);
        }

        public static clsTestType Find(int TestTypeID)
        {
            string TestTypeTitle = "";
            string TestTypeDescription = "";
            decimal TestTypeFees = 0;

            if (clsTestTypeDataAccess.GetInfoByTestTypeID(TestTypeID,
                ref TestTypeTitle, ref TestTypeDescription, ref TestTypeFees))
            {
                return new clsTestType(TestTypeID, TestTypeTitle, TestTypeDescription, 
                    TestTypeFees);
            }
            else
            {
                return null;
            }

        }

    }
}
