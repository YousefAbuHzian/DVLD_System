﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace DataAccessLayer
{
    public class clsCountryDataAccess
    {
        public static string GetCountryNameByID(int CountryID)
        {
            string result = "";
            SqlConnection connection = new SqlConnection(DataAccessSettings.ConnectionString);
            string query = "Select CountryName from Countries Where CountryID = @CountryID";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@CountryID", CountryID);

            try
            {
                connection.Open();

                result = (string)command.ExecuteScalar();

            }
            catch
            {
                result = "";

            }
            finally
            {
                connection.Close();
            }
            return result;
        }

        public static int GetCountryIDByName(string CountryName)
        {
            int CountryID = -1;
            SqlConnection connection = new SqlConnection(DataAccessSettings.ConnectionString);
            string query = "Select CountryID from Countries Where CountryName = @CountryName";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@CountryName", CountryName);

            try
            {
                connection.Open();

                CountryID = (int)command.ExecuteScalar();

            }
            catch
            {
                CountryID = -1;

            }
            finally
            {
                connection.Close();
            }
            return CountryID;
        }

        public static DataTable GetAllCountries()
        {
            DataTable dt = new DataTable();
            SqlConnection connection = new SqlConnection(DataAccessSettings.ConnectionString);
            string query = "Select * from Countries";
            SqlCommand command = new SqlCommand(query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    dt.Load(reader);
                }
                reader.Close();
            }
            catch
            {
                dt = null;
            }
            finally
            {
                connection.Close();
            }
            return dt;
        }

    }
}
