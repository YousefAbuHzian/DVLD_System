﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DataAccessLayer
{
    public class clsTestAppointmentDataAccess
    {
        public static bool GetInfoByTestAppointmentID(int TestAppointmentID, ref int TestTypeID, ref int LDLAppID,
            ref DateTime AppointmentDate, ref decimal PaidFees, ref int CreatedByUserID, ref bool IsLocked, ref int RTAppID)
        {
            bool IsFound = false;

            SqlConnection connection = new SqlConnection(DataAccessSettings.ConnectionString);

            string query = @"Select * from TestAppointments Where TestAppointmentID = @TestAppointmentID";
            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@TestAppointmentID", TestAppointmentID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    IsFound = true;
                    TestTypeID = Convert.ToInt32(reader["TestTypeID"]);
                    LDLAppID = Convert.ToInt32(reader["LocalDrivingLicenseApplicationID"]);
                    AppointmentDate = (DateTime)reader["AppointmentDate"];
                    PaidFees = Convert.ToDecimal(reader["PaidFees"]);
                    CreatedByUserID = Convert.ToInt32(reader["CreatedByUserID"]);
                    IsLocked = (bool)reader["IsLocked"];
                    if (reader["RetakeTestApplicationID"] != System.DBNull.Value)
                        RTAppID = Convert.ToInt32(reader["RetakeTestApplicationID"]);
                    else
                        RTAppID = -1;

                }
                else
                {
                    IsFound = false;
                }
                reader.Close();
            }

            catch 
            {
                //throw;
                IsFound = false;
            }
            finally
            {
                connection.Close();
            }
            return IsFound;
        }
      

        public static DataTable GetAllTestAppointmentsByTestTypeIDAndLDLAppID(int TestTypeID, int LDLAppID)
        {
            DataTable dt = new DataTable();
            SqlConnection connection = new SqlConnection(DataAccessSettings.ConnectionString);

            string query = @"Select TestAppointmentID, AppointmentDate, PaidFees, IsLocked from TestAppointments
                Where TestTypeID = @TestTypeID and LocalDrivingLicenseApplicationID = @LDLAppID";

            // query = "Select * from TestAppointments";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@LDLAppID", LDLAppID);
            command.Parameters.AddWithValue("@TestTypeID", TestTypeID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    dt.Load(reader);
                }
                reader.Close();
            }
            catch
            {
                dt = null;
            }
            finally
            {
                connection.Close();
            }
            return dt;
        }

        public static bool GetLastTestAppointment(
             int LocalDrivingLicenseApplicationID, int TestTypeID,
            ref int TestAppointmentID, ref DateTime AppointmentDate,
            ref decimal PaidFees, ref int CreatedByUserID, ref bool IsLocked, ref int RetakeTestApplicationID)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(DataAccessSettings.ConnectionString);

            string query = @"SELECT       top 1 *
                FROM            TestAppointments
                WHERE        (TestTypeID = @TestTypeID) 
                AND (LocalDrivingLicenseApplicationID = @LocalDrivingLicenseApplicationID) 
                order by TestAppointmentID Desc";


            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@LocalDrivingLicenseApplicationID", LocalDrivingLicenseApplicationID);
            command.Parameters.AddWithValue("@TestTypeID", TestTypeID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {

                    // The record was found
                    isFound = true;

                    TestAppointmentID = (int)reader["TestAppointmentID"];
                    AppointmentDate = (DateTime)reader["AppointmentDate"];
                    PaidFees = Convert.ToDecimal(reader["PaidFees"]);
                    CreatedByUserID = (int)reader["CreatedByUserID"];
                    IsLocked = (bool)reader["IsLocked"];

                    if (reader["RetakeTestApplicationID"] == DBNull.Value)
                        RetakeTestApplicationID = -1;
                    else
                        RetakeTestApplicationID = (int)reader["RetakeTestApplicationID"];


                }
                else
                {
                    // The record was not found
                    isFound = false;
                }

                reader.Close();


            }
            catch 
            {
                //Console.WriteLine("Error: " + ex.Message);
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static int AddNewTestAppointment( int TestTypeID,  int LDLAppID,
             DateTime AppointmentDate,  decimal PaidFees,  int CreatedByUserID,  bool IsLocked,
             int RTAppID)
        {     

            int TestAppointmentID = -1;
            SqlConnection connection = new SqlConnection(DataAccessSettings.ConnectionString);
            string query = @"INSERT INTO TestAppointments ([TestTypeID],[LocalDrivingLicenseApplicationID] ,[AppointmentDate],[PaidFees],
        [CreatedByUserID], [IsLocked], [RetakeTestApplicationID])
            VALUES
	            (@TestTypeID, @LDLAppID, @AppointmentDate, @PaidFees, @CreatedByUserID, @IsLocked, @RTAppID);
	                    Select SCOPE_IDENTITY();";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@TestTypeID", TestTypeID);
            command.Parameters.AddWithValue("@LDLAppID", LDLAppID);
            command.Parameters.AddWithValue("@AppointmentDate", AppointmentDate);
            command.Parameters.AddWithValue("@PaidFees", PaidFees);
            command.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);
            command.Parameters.AddWithValue("@IsLocked", IsLocked);
            if(RTAppID == -1)
                command.Parameters.AddWithValue("@RTAppID", System.DBNull.Value);
            else
                command.Parameters.AddWithValue("@RTAppID", RTAppID);

            try
            {
                connection.Open();
                object result = command.ExecuteScalar();
                if (int.TryParse(result.ToString(), out int inserted))
                {
                    TestAppointmentID = inserted;
                }
                else
                    TestAppointmentID = -1;
            }
            catch
            {
                TestAppointmentID = -1;
            }
            finally
            {
                connection.Close();
            }
            return TestAppointmentID;
        }

        public static bool UpdateTestAppointment(int TestAppointmentID, int TestTypeID, int LDLAppID,
             DateTime AppointmentDate, decimal PaidFees, int CreatedByUserID, bool IsLocked,
             int RTAppID)
        {
            int rowsAffected = 0;
            SqlConnection connection = new SqlConnection(DataAccessSettings.ConnectionString);
            string query = @"Update TestAppointments 
                            Set TestTypeID = @TestTypeID,
                                LocalDrivingLicenseApplicationID = @LDLAppID,
                                AppointmentDate = @AppointmentDate,
                                PaidFees = @PaidFees,
                                CreatedByUserID = @CreatedByUserID,
                                IsLocked = @IsLocked,
                                RetakeTestApplicationID = @RTAppID
                            Where TestAppointmentID = @TestAppointmentID";
            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@TestAppointmentID", TestAppointmentID);
            command.Parameters.AddWithValue("@TestTypeID", TestTypeID);
            command.Parameters.AddWithValue("@LDLAppID", LDLAppID);
            command.Parameters.AddWithValue("@AppointmentDate", AppointmentDate);
            command.Parameters.AddWithValue("@PaidFees", PaidFees);
            command.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);
            command.Parameters.AddWithValue("@IsLocked", IsLocked);
            if(RTAppID == -1)
                command.Parameters.AddWithValue("@RTAppID", System.DBNull.Value);
            else
                command.Parameters.AddWithValue("@RTAppID", RTAppID);


            try
            {
                connection.Open();
                rowsAffected = command.ExecuteNonQuery();

            }
            catch
            {
                rowsAffected = 0;
            }
            finally { connection.Close(); }
            return (rowsAffected > 0);
        }

        public static bool DeleteTestAppointment(int TestAppointmentID)
        {
            int rowsAffected = 0;
            SqlConnection connection = new SqlConnection(DataAccessSettings.ConnectionString);

            string query = @"Delete TestAppointments 
                            Where TestAppointmentID = @TestAppointmentID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@TestAppointmentID", TestAppointmentID);

            try
            {
                connection.Open();
                rowsAffected = command.ExecuteNonQuery();

            }
            catch
            {
                return false;
            }
            finally
            {
                connection.Close();
            }
            return (rowsAffected > 0);
        }

        //public static bool IsExist(int TestAppointmentID)
        //{
        //    bool isFound = false;
        //    SqlConnection connection = new SqlConnection(DataAccessSettings.ConnectionString);
        //    string query = @"Select Found = 1 From TestAppointments
        //                        Where TestAppointmentID = @TestAppointmentID";
        //    SqlCommand command = new SqlCommand(query, connection);

        //    command.Parameters.AddWithValue("@TestAppointmentID", TestAppointmentID);

        //    try
        //    {
        //        connection.Open();
        //        SqlDataReader reader = command.ExecuteReader();

        //        if (reader.HasRows)
        //        {
        //            isFound = true;
        //        }
        //        else
        //            isFound = false;
        //        reader.Close();
        //    }
        //    catch
        //    {
        //        isFound = false;
        //    }
        //    finally
        //    {
        //        connection.Close();
        //    }
        //    return isFound;
        //}

        
        public static bool IsPassed(int TestAppointmentID)
        {
            bool isFound = false;
            SqlConnection connection = new SqlConnection( DataAccessSettings.ConnectionString);
            string query = @"SELECT TestResult from Tests 
                    Where TestAppointmentID = @TestAppointmentID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@TestAppointmentID", TestAppointmentID);
            try
            {
                connection.Open();
                object result = command.ExecuteScalar();
                if (bool.TryParse(result.ToString(), out bool inserted))
                {
                    isFound = inserted;
                }
                else
                {
                    isFound = false;
                }
            }
            catch
            {
                return false;
            }
            finally
            {
                connection.Close();
            }
            return isFound;
            
        }


        public static int GetRetakeTestAppIDByTestAppointment(int TestAppointmentID)
        {
            int RetakeTestAppID = -1;
            SqlConnection connection = new SqlConnection(DataAccessSettings.ConnectionString);
            string query = @"SELECT RetakeTestApplicationID from TestAppointments 
                    Where TestAppointmentID = @TestAppointmentID";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@TestAppointmentID", TestAppointmentID);

            try
            {
                connection.Open();
                object result = command.ExecuteScalar();
                if(result != null)
                {
                    if(int.TryParse(result.ToString(), out int inserted))
                    {
                        RetakeTestAppID = inserted;
                    }
                }
                else
                {
                    RetakeTestAppID = -1;
                }
            }
            catch
            {
                return -1;
            }
            finally
            {
                connection.Close() ;
            }
            return RetakeTestAppID; 

        }

        public static int GetTestID(int TestAppointmentID)
        {
            int TestID = -1;
            SqlConnection connection = new SqlConnection(DataAccessSettings.ConnectionString);

            string query = @"select TestID from Tests where TestAppointmentID=@TestAppointmentID;";

            SqlCommand command = new SqlCommand(query, connection);


            command.Parameters.AddWithValue("@TestAppointmentID", TestAppointmentID);


            try
            {
                connection.Open();

                object result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    TestID = insertedID;
                }
            }

            catch 
            {
                //Console.WriteLine("Error: " + ex.Message);

            }

            finally
            {
                connection.Close();
            }


            return TestID;

        }

    }
}
